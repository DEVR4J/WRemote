WORLDREMOTE ACCESSIBILITY XML BUILD FIX

Replace the matching files in your existing project with:
- app/src/main/res/xml/accessibility_service_config.xml
- app/src/main/res/values/strings.xml

Then commit/push the changes or rerun GitHub Actions.
