package com.worldremote.agent;

import android.accessibilityservice.AccessibilityService;
import android.view.accessibility.AccessibilityEvent;

public class RemoteAccessibilityService extends AccessibilityService {
    private static RemoteAccessibilityService instance;
    @Override public void onServiceConnected() { instance = this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }
    @Override public void onDestroy() { if (instance == this) instance = null; super.onDestroy(); }
    public static boolean global(String action) {
        if (instance == null) return false;
        if ("home".equals(action)) return instance.performGlobalAction(GLOBAL_ACTION_HOME);
        if ("back".equals(action)) return instance.performGlobalAction(GLOBAL_ACTION_BACK);
        return false;
    }
}
