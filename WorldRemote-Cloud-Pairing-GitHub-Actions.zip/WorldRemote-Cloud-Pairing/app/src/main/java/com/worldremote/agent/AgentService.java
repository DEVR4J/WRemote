package com.worldremote.agent;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.UUID;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

public class AgentService extends Service {
    public static final String PREFS = "worldremote";
    public static final String ACTION_STATUS = "com.worldremote.agent.STATUS";
    private static final String CHANNEL = "worldremote_agent";
    private static final String TAG = "WorldRemote";
    private OkHttpClient client;
    private WebSocket socket;
    private boolean stopping = false;

    @Override public void onCreate() {
        super.onCreate();
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel(CHANNEL, "WorldRemote Agent", NotificationManager.IMPORTANCE_LOW));
            Notification n = new Notification.Builder(this, CHANNEL)
                .setContentTitle("WorldRemote Agent")
                .setContentText("Cloud connection service is active")
                .setSmallIcon(android.R.drawable.stat_sys_remote).setOngoing(true).build();
            startForeground(4107, n);
        }
        client = new OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        stopping = false;
        connect();
        return START_STICKY;
    }

    private void connect() {
        if (stopping || socket != null) return;
        android.content.SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String base = p.getString("relay", "").trim();
        String device = p.getString("device", "");
        String code = p.getString("code", "");
        if (base.isEmpty() || device.isEmpty() || code.isEmpty()) { broadcast("Not configured"); return; }
        String wsBase = base.replaceFirst("^https://", "wss://").replaceFirst("^http://", "ws://");
        String url = wsBase + "/ws/tv?deviceId=" + enc(device) + "&code=" + enc(code);
        broadcast("Connecting…");
        Request req = new Request.Builder().url(url).build();
        socket = client.newWebSocket(req, new WebSocketListener() {
            @Override public void onOpen(WebSocket webSocket, Response response) { broadcast("Connected · waiting for pairing"); }
            @Override public void onMessage(WebSocket webSocket, String text) {
                try {
                    JSONObject msg = new JSONObject(text);
                    String type = msg.optString("type");
                    if ("paired".equals(type)) broadcast("Paired · cloud connected");
                    else if ("command".equals(type)) handleCommand(msg.optString("action"));
                    else if ("ping".equals(type)) webSocket.send("{\"type\":\"pong\"}");
                } catch (Exception e) { Log.e(TAG, "Invalid cloud message", e); }
            }
            @Override public void onClosing(WebSocket webSocket, int code, String reason) { webSocket.close(1000, null); }
            @Override public void onClosed(WebSocket webSocket, int code, String reason) { socket = null; broadcast("Disconnected · retrying"); scheduleReconnect(); }
            @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) { socket = null; broadcast("Connection failed · retrying"); Log.e(TAG, "WebSocket failure", t); scheduleReconnect(); }
        });
    }

    private void scheduleReconnect() {
        if (!stopping) new android.os.Handler(getMainLooper()).postDelayed(this::connect, 8000);
    }
    private String enc(String s) { try { return URLEncoder.encode(s, "UTF-8"); } catch (Exception e) { return s; } }
    private void broadcast(String status) { Intent i = new Intent(ACTION_STATUS); i.putExtra("status", status); sendBroadcast(i); }

    private void handleCommand(String action) {
        AudioManager audio = (AudioManager)getSystemService(Context.AUDIO_SERVICE);
        boolean ok = false;
        switch (action) {
            case "volume_up": audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI); ok = true; break;
            case "volume_down": audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI); ok = true; break;
            case "mute": audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0); ok = true; break;
            case "unmute": audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0); ok = true; break;
            case "home": case "back": ok = RemoteAccessibilityService.global(action); break;
            case "youtube": ok = launch("com.google.android.youtube.tv", "com.google.android.youtube"); break;
            case "netflix": ok = launch("com.netflix.ninja"); break;
        }
        if (socket != null) {
            try { JSONObject ack = new JSONObject(); ack.put("type", "ack"); ack.put("action", action); ack.put("ok", ok); socket.send(ack.toString()); } catch (Exception ignored) {}
        }
        broadcast(ok ? "Command executed: " + action : "Command unavailable: " + action);
    }

    private boolean launch(String... packages) {
        for (String pkg : packages) {
            try { Intent i = getPackageManager().getLaunchIntentForPackage(pkg); if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return true; } } catch (Exception ignored) {}
        }
        return false;
    }

    @Override public void onDestroy() { stopping = true; if (socket != null) socket.close(1000, "service stopped"); if (client != null) client.dispatcher().executorService().shutdown(); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent) { return null; }
}
