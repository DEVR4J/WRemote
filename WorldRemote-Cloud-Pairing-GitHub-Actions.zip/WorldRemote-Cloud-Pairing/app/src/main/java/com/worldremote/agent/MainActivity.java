package com.worldremote.agent;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.UUID;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView status;
    private EditText relay;
    private final BroadcastReceiver receiver = new BroadcastReceiver() { @Override public void onReceive(Context c, Intent i) { if (status != null) status.setText(i.getStringExtra("status")); } };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(17,19,39)); getWindow().setNavigationBarColor(Color.rgb(17,19,39));
        android.content.SharedPreferences p = getSharedPreferences(AgentService.PREFS, MODE_PRIVATE);
        if (p.getString("device", "").isEmpty()) p.edit().putString("device", UUID.randomUUID().toString()).apply();
        if (p.getString("code", "").isEmpty()) p.edit().putString("code", String.format(java.util.Locale.US, "%06d", new java.security.SecureRandom().nextInt(1000000))).apply();
        render();
        IntentFilter f = new IntentFilter(AgentService.ACTION_STATUS);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED); else registerReceiver(receiver, f);
    }

    private void render() {
        ScrollView sc = new ScrollView(this); sc.setBackgroundColor(0xFF111327);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(30),dp(25),dp(30),dp(30)); sc.addView(root);
        TextView brand = txt("WORLDREMOTE  /  TV AGENT",13,0xFFB8A7FF,true); root.addView(brand);
        TextView title = txt("Connect your TV.\nControl it remotely.",31,Color.WHITE,true); LinearLayout.LayoutParams tlp = lp(); tlp.topMargin=dp(15); root.addView(title,tlp);
        TextView desc = txt("Cloud pairing edition · Android TV",15,0xFFB9BED6,false); LinearLayout.LayoutParams dlp=lp(); dlp.topMargin=dp(9); root.addView(desc,dlp);

        LinearLayout card = card(root, 24);
        card.addView(txt("PAIRING CODE",12,0xFFB8A7FF,true));
        String code = getSharedPreferences(AgentService.PREFS,MODE_PRIVATE).getString("code","------");
        TextView codeView = txt(code,42,Color.WHITE,true); codeView.setGravity(Gravity.CENTER); LinearLayout.LayoutParams clp=lp(); clp.topMargin=dp(8); card.addView(codeView,clp);
        TextView hint = txt("Open your deployed WorldRemote relay URL on your phone and enter this code to pair.",14,0xFFD0D3E5,false); hint.setGravity(Gravity.CENTER); LinearLayout.LayoutParams hlp=lp(); hlp.topMargin=dp(8); card.addView(hint,hlp);

        LinearLayout config = card(root, 18); config.addView(txt("CLOUD RELAY URL",12,0xFFB8A7FF,true));
        relay = new EditText(this); relay.setSingleLine(true); relay.setTextColor(Color.WHITE); relay.setHintTextColor(0xFF858BAA); relay.setHint("https://your-worker.workers.dev"); relay.setText(getSharedPreferences(AgentService.PREFS,MODE_PRIVATE).getString("relay",""));
        relay.setSelectAllOnFocus(false); relay.setPadding(dp(12),dp(10),dp(12),dp(10)); relay.setBackgroundColor(0xFF343956); LinearLayout.LayoutParams rlp=lp(); rlp.topMargin=dp(10); config.addView(relay,rlp);
        Button connect = button("SAVE & CONNECT"); LinearLayout.LayoutParams blp=lp(); blp.topMargin=dp(14); config.addView(connect,blp);
        connect.setOnClickListener(v -> { String url=relay.getText().toString().trim().replaceAll("/$", ""); if (!url.startsWith("https://")) { relay.setError("Use your secure https:// relay URL"); return; } getSharedPreferences(AgentService.PREFS,MODE_PRIVATE).edit().putString("relay",url).apply(); Intent s=new Intent(this,AgentService.class); if(Build.VERSION.SDK_INT>=26) startForegroundService(s); else startService(s); status.setText("Starting connection…"); });

        LinearLayout st = card(root,18); st.addView(txt("CONNECTION STATUS",12,0xFFB8A7FF,true)); status=txt("Not connected",18,Color.WHITE,true); LinearLayout.LayoutParams slp=lp(); slp.topMargin=dp(8); st.addView(status,slp);
        Button access=button("ENABLE OPTIONAL HOME / BACK ACCESS"); LinearLayout.LayoutParams alp=lp(); alp.topMargin=dp(12); st.addView(access,alp); access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        TextView foot=txt("Volume and supported app-launch commands work without Accessibility. Home and Back require you to explicitly enable the optional WorldRemote accessibility service. This app cannot wake a TV that has fully powered off.",13,0xFFB9BED6,false); LinearLayout.LayoutParams flp=lp(); flp.topMargin=dp(18); root.addView(foot,flp);
        setContentView(sc);
    }
    private LinearLayout card(LinearLayout root,int pad) { LinearLayout c=new LinearLayout(this); c.setOrientation(1); c.setPadding(dp(pad),dp(pad),dp(pad),dp(pad)); c.setBackgroundColor(0xFF252945); LinearLayout.LayoutParams p=lp(); p.topMargin=dp(18); root.addView(c,p); return c; }
    private TextView txt(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); t.setTypeface(Typeface.create("sans-serif",bold?Typeface.BOLD:Typeface.NORMAL)); t.setLineSpacing(dp(4),1f); return t; }
    private Button button(String s) { Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF6559A8)); return b; }
    private LinearLayout.LayoutParams lp() { return new LinearLayout.LayoutParams(-1,-2); }
    @Override protected void onDestroy() { try { unregisterReceiver(receiver); } catch(Exception ignored){} super.onDestroy(); }
}
