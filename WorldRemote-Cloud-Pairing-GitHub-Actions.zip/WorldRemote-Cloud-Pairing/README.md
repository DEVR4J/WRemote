# WorldRemote 1.1 — Cloud Pairing Edition

This ZIP contains:
- `app/`: Android TV Agent APK source (Android 6+; designed/tested target API compatibility includes Android 9).
- `cloudflare-worker/`: Cloudflare Worker + Durable Object relay and mobile browser remote page.
- `.github/workflows/build.yml`: GitHub Actions debug APK build.

## A. Build the TV Agent APK with GitHub Actions
1. Create a GitHub repository (for example `WorldRemote`).
2. Upload the **contents** of this ZIP to the repository root (not an extra enclosing folder).
3. Open **Actions → Build WorldRemote TV Agent APK → Run workflow**.
4. Download artifact `WorldRemote-TV-Agent-1.1-debug`; extract `app-debug.apk`.

## B. Deploy the cloud relay
You need a Cloudflare account and Node.js/npm on a computer or in Termux/Ubuntu.
1. Install Wrangler: `npm install -g wrangler`
2. Sign in: `wrangler login`
3. From the `cloudflare-worker` directory run: `wrangler deploy`
4. Copy the deployed `https://worldremote-relay.<your-subdomain>.workers.dev` URL.

The worker uses one Durable Object to keep live TV WebSockets and pair sessions. Review Cloudflare's current Durable Objects pricing/limits before relying on it for always-on use.

## C. Pair the TV
1. Install and open WorldRemote Agent on the TV.
2. Enter the deployed Worker URL in **Cloud Relay URL** (must begin `https://`).
3. Select **Save & Connect**. Keep the app open for initial pairing.
4. On your phone, open the same Worker URL in a browser.
5. Enter the six-digit pairing code displayed on the TV and select Pair.

The code is short-lived (15 minutes). The browser receives a long random bearer token stored in that browser's local storage. Unpair by selecting **Unpair this browser**.

## D. Supported commands in this milestone
- Volume up/down, mute/unmute (AudioManager)
- Launch YouTube / Netflix if their TV packages are installed
- Home / Back only after the user explicitly enables the WorldRemote accessibility service in Android Accessibility settings

This milestone proves cloud pairing and command delivery. It is **not** full remote-control parity: D-pad/OK, text input, screen mirroring, TV power-on, and deep-standby wake are not implemented. Android TV vendors expose different APIs. A fully powered-off TV cannot receive commands through this app alone.

## Security notes
- The TV initiates an outbound `wss://` connection; do not expose ADB or port 5555 to the internet.
- Pair only on a trusted device/browser. The bearer token grants control to that browser; clear/unpair it if the phone is lost.
- This starter relay keeps active socket mappings in Durable Object memory. If the Worker restarts or a TV reconnects, pair/status may need refreshing. For production, add durable device/session lifecycle, rate limits, token revocation, account authentication and audit logs.
- Do not put private credentials in the Git repository.
