export class WorldRemoteHub {
  constructor(state, env) { this.state = state; this.env = env; }
  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === "/ws/tv") return this.connectTv(request, url);
    if (url.pathname === "/api/pair" && request.method === "POST") return this.pair(request);
    if (url.pathname === "/api/command" && request.method === "POST") return this.command(request);
    if (url.pathname === "/api/status" && request.method === "GET") return this.status(request);
    if (url.pathname === "/api/unpair" && request.method === "POST") return this.unpair(request);
    return new Response("Not found", { status: 404 });
  }
  async connectTv(request, url) {
    if (request.headers.get("Upgrade") !== "websocket") return new Response("Expected WebSocket", { status: 426 });
    const deviceId = url.searchParams.get("deviceId");
    const code = url.searchParams.get("code");
    if (!deviceId || !/^\d{6}$/.test(code || "")) return new Response("Invalid device or pairing code", { status: 400 });
    const pairKey = `code:${code}`;
    const existing = await this.state.storage.get(pairKey);
    if (existing && existing.deviceId !== deviceId) return new Response("Pairing code collision; restart TV agent", { status: 409 });
    await this.state.storage.put(pairKey, { deviceId, createdAt: Date.now() });
    const pair = new WebSocketPair();
    const [client, server] = Object.values(pair);
    this.state.acceptWebSocket(server, [`tv:${deviceId}`]);
    server.serializeAttachment({ deviceId, code });
    server.send(JSON.stringify({ type: "connected" }));
    return new Response(null, { status: 101, webSocket: client });
  }
  async pair(request) {
    const body = await request.json().catch(() => ({}));
    const code = String(body.code || "");
    if (!/^\d{6}$/.test(code)) return Response.json({ error: "Enter the six-digit code shown on the TV." }, { status: 400 });
    const record = await this.state.storage.get(`code:${code}`);
    if (!record || Date.now() - record.createdAt > 15 * 60 * 1000) return Response.json({ error: "Code not found or expired. Reconnect the TV agent to generate a fresh code." }, { status: 404 });
    const token = randomToken();
    await this.state.storage.put(`token:${token}`, { deviceId: record.deviceId, createdAt: Date.now() });
    const sockets = this.state.getWebSockets(`tv:${record.deviceId}`);
    if (!sockets.length) return Response.json({ error: "TV is offline. Keep WorldRemote Agent open and connected." }, { status: 409 });
    sockets[0].send(JSON.stringify({ type: "paired" }));
    return Response.json({ deviceId: record.deviceId, token, paired: true });
  }
  async command(request) {
    const token = (request.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
    const session = await this.state.storage.get(`token:${token}`);
    if (!session) return Response.json({ error: "Unauthorized. Pair this browser again." }, { status: 401 });
    const body = await request.json().catch(() => ({}));
    const allowed = new Set(["volume_up", "volume_down", "mute", "unmute", "home", "back", "youtube", "netflix"]);
    if (!allowed.has(body.action)) return Response.json({ error: "Unsupported command" }, { status: 400 });
    const sockets = this.state.getWebSockets(`tv:${session.deviceId}`);
    if (!sockets.length) return Response.json({ error: "TV is offline" }, { status: 409 });
    sockets[0].send(JSON.stringify({ type: "command", action: body.action }));
    return Response.json({ sent: true, action: body.action });
  }
  async unpair(request) {
    const token = (request.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
    if (!token) return Response.json({ error: "Unauthorized" }, { status: 401 });
    await this.state.storage.delete(`token:${token}`);
    return Response.json({ unpaired: true });
  }
  async status(request) {
    const token = (request.headers.get("Authorization") || "").replace(/^Bearer\s+/i, "");
    const session = await this.state.storage.get(`token:${token}`);
    if (!session) return Response.json({ error: "Unauthorized" }, { status: 401 });
    const online = this.state.getWebSockets(`tv:${session.deviceId}`).length > 0;
    return Response.json({ deviceId: session.deviceId, online });
  }
  async webSocketMessage(ws, message) {
    // The TV agent sends only acknowledgements and keep-alive replies in this version.
    try { const data = JSON.parse(message); if (data.type === "ack") console.log("TV command ack", data.action, data.ok); } catch (_) {}
  }
  async webSocketClose(ws) { try { const a = ws.deserializeAttachment(); await this.state.storage.delete(`code:${a.code}`); } catch (_) {} }
  async webSocketError(ws) { try { ws.close(1011, "socket error"); } catch (_) {} }
}

function randomToken() {
  const bytes = new Uint8Array(32); crypto.getRandomValues(bytes);
  return Array.from(bytes, b => b.toString(16).padStart(2, "0")).join("");
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === "/" || url.pathname === "/index.html") return new Response(PAGE, { headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" } });
    const id = env.HUB.idFromName("global-worldremote-hub");
    return env.HUB.get(id).fetch(request);
  }
};

const PAGE = `<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="theme-color" content="#171a35"><title>WorldRemote</title><style>
*{box-sizing:border-box}body{margin:0;background:radial-gradient(circle at 15% 0,#38345f,#111327 55%);color:#fff;font:16px system-ui;min-height:100vh;padding:24px}.wrap{max-width:460px;margin:30px auto}.brand{color:#b8a7ff;letter-spacing:.18em;font-weight:800;font-size:12px}.card{background:#252945;border:1px solid #414665;border-radius:24px;padding:22px;margin-top:18px;box-shadow:0 16px 40px #0003}h1{font-size:34px;line-height:1.08;margin:14px 0}p{color:#c6c9dc;line-height:1.5}.muted{color:#aeb4ce;font-size:13px}.row{display:flex;gap:10px}input{min-width:0;flex:1;background:#171a35;border:1px solid #4a4f70;color:#fff;border-radius:12px;padding:14px;font-size:18px;letter-spacing:.12em}button{border:0;border-radius:14px;padding:14px 16px;background:#7568bd;color:white;font-weight:750;font-size:14px;cursor:pointer}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:10px;margin-top:15px}.grid button{min-height:58px}.wide{width:100%;margin-top:10px}.hidden{display:none}.status{padding:10px 12px;background:#171a35;border-radius:12px;color:#cfc8ff}.error{color:#ffb7c3}.ok{color:#a6f0c0}</style></head><body><div class="wrap"><div class="brand">WORLDREMOTE</div><h1>Your TV,<br>within reach.</h1><p>Pair your Android TV agent once, then send supported controls over the internet.</p><section id="pairCard" class="card"><h3>Pair your television</h3><p class="muted">Enter the six-digit code displayed by WorldRemote Agent on your TV.</p><div class="row"><input id="code" inputmode="numeric" maxlength="6" placeholder="000000"><button id="pair">PAIR</button></div><p id="msg" class="muted"></p></section><section id="remote" class="card hidden"><div class="status" id="status">Checking TV…</div><h3>Remote controls</h3><div class="grid"><button data-action="home">⌂<br>Home</button><button data-action="back">↩<br>Back</button><button data-action="mute">◖<br>Mute</button><button data-action="volume_down">−<br>Volume</button><button data-action="volume_up">＋<br>Volume</button><button data-action="unmute">◖<br>Unmute</button></div><button class="wide" data-action="youtube">Open YouTube</button><button class="wide" data-action="netflix">Open Netflix</button><button class="wide" id="unpair" style="background:#484d68">Unpair this browser</button><p id="result" class="muted"></p></section></div><script>
const $=id=>document.getElementById(id);let token=localStorage.getItem('wr_token');
async function api(path,body){const r=await fetch(path,{method:body?'POST':'GET',headers:{'content-type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},body:body?JSON.stringify(body):undefined});const j=await r.json();if(!r.ok)throw Error(j.error||'Request failed');return j}
function showRemote(){ $('pairCard').classList.add('hidden');$('remote').classList.remove('hidden');refresh();setInterval(refresh,12000)}
async function refresh(){try{const s=await api('/api/status');$('status').textContent=s.online?'● TV online':'○ TV offline';$('status').className='status '+(s.online?'ok':'error')}catch(e){$('status').textContent=e.message}}
$('pair').onclick=async()=>{ $('msg').textContent='Pairing…';try{const r=await api('/api/pair',{code:$('code').value.trim()});token=r.token;localStorage.setItem('wr_token',token);showRemote()}catch(e){$('msg').textContent=e.message;$('msg').className='error'}};
document.querySelectorAll('[data-action]').forEach(b=>b.onclick=async()=>{try{const r=await api('/api/command',{action:b.dataset.action});$('result').textContent='Sent: '+r.action}catch(e){$('result').textContent=e.message}});
$('unpair').onclick=async()=>{try{await api('/api/unpair',{});}catch(e){}localStorage.removeItem('wr_token');token=null;location.reload()};if(token)showRemote();
</script></body></html>`;
