# TV app
Unzip, upload everything (incl. hidden .github) to GitHub on main. APK: Actions > run > Artifacts.
Home Wi-Fi works with no server. Internet access: set a server inside the app (optional).
