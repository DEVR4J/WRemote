# TV app
Unzip, upload everything (incl. hidden .github folder) to a GitHub repo on main. APK appears under Actions > run > Artifacts.
Set repo variable SERVER_URL (wss://...) and re-run for a working build.
