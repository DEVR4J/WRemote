plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.example.tvagent"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.example.tvagent"
        minSdk = 26
        targetSdk = 28   // Mi TV A4 runs Android 9
        versionCode = 1
        versionName = "1.0"
        ndk { abiFilters += listOf("armeabi-v7a", "arm64-v8a") }
    }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    packaging { resources { excludes += setOf("META-INF/*.kotlin_module", "META-INF/DEPENDENCIES", "META-INF/INDEX.LIST", "META-INF/LICENSE*", "META-INF/NOTICE*") } }
    lint { abortOnError = false; checkReleaseBuilds = false }
}
dependencies {
    implementation("io.github.webrtc-sdk:android:125.6422.07")
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
    implementation("dev.mobile:dadb:1.2.9")
    implementation("org.java-websocket:Java-WebSocket:1.5.6")
}
