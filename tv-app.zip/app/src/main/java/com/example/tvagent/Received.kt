package com.example.tvagent

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.StrictMode
import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Remembers every file received from the phone (name, place, date and time) and opens them. */
object Received {
    class Item(val name: String, val where: String, val uri: String?, val path: String?, val size: Long, val time: Long)

    private fun store(ctx: Context) = File(ctx.filesDir, "received.json")

    fun all(ctx: Context): List<Item> {
        val f = store(ctx)
        if (!f.exists()) return emptyList()
        return try {
            val a = JSONArray(f.readText())
            (0 until a.length()).map { k ->
                val o = a.getJSONObject(k)
                Item(o.getString("name"), o.optString("where"), o.optString("uri").ifEmpty { null },
                    o.optString("path").ifEmpty { null }, o.optLong("size"), o.optLong("time"))
            }
        } catch (e: Exception) { emptyList() }
    }

    @Synchronized
    fun add(ctx: Context, name: String, where: String, uri: String?, path: String?, size: Long) {
        val old = all(ctx)
        val a = JSONArray()
        a.put(JSONObject().put("name", name).put("where", where).put("uri", uri ?: "").put("path", path ?: "")
            .put("size", size).put("time", System.currentTimeMillis()))
        for (i in old.take(199)) {
            a.put(JSONObject().put("name", i.name).put("where", i.where).put("uri", i.uri ?: "").put("path", i.path ?: "")
                .put("size", i.size).put("time", i.time))
        }
        store(ctx).writeText(a.toString())
    }

    /** Opens the file in another app. Returns an error message, or null when it worked. */
    fun open(ctx: Context, item: Item): String? {
        val ext = item.name.substringAfterLast('.', "").lowercase()
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "*/*"
        val uri: Uri = when {
            item.uri != null -> Uri.parse(item.uri)
            item.path != null -> {
                if (!File(item.path).exists()) return "This file is no longer on the TV"
                // old Android (target 28) refuses file:// links unless this check is relaxed
                try { StrictMode.setVmPolicy(StrictMode.VmPolicy.Builder().build()) } catch (e: Exception) {}
                Uri.fromFile(File(item.path))
            }
            else -> return "File location unknown"
        }
        return try {
            ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION))
            null
        } catch (e: Exception) { "No app on this TV can open this kind of file" }
    }
}
