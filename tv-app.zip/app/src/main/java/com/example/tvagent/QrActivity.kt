package com.example.tvagent

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.Layout
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** Full page with the big QR code. Sizes follow a 1050 x 600 design and scale to the real screen. */
class QrActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val u = resources.displayMetrics.heightPixels / 600f
        fun px(v: Float) = (v * u).toInt()
        val match = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        fun label(text: String, size: Float, color: String, bold: Boolean = false, justify: Boolean = false) = TextView(this).apply {
            this.text = text
            setTextSize(TypedValue.COMPLEX_UNIT_PX, size * u)
            setTextColor(Color.parseColor(color))
            if (bold) setTypeface(null, Typeface.BOLD)
            if (justify && Build.VERSION.SDK_INT >= 26) justificationMode = Layout.JUSTIFICATION_MODE_INTER_WORD
        }

        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.parseColor("#FAFAFA")) }

        // title bar
        val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setBackgroundColor(Color.parseColor("#333336")); setPadding(px(16f), 0, 0, 0) }
        bar.addView(ImageView(this).apply { setImageResource(R.mipmap.ic_launcher) }, LinearLayout.LayoutParams(px(26f), px(26f)))
        bar.addView(label("Anywhere TV Control - TV", 21f, "#FFFFFF", bold = true).apply { setPadding(px(14f), 0, 0, 0) })
        root.addView(bar, LinearLayout.LayoutParams(match, px(37f)))

        // row: text | QR | tagline
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }

        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_VERTICAL; setPadding(px(45f), 0, px(5f), 0) }
        left.addView(label("Scan QR  >>", 22f, "#666666", bold = true))
        left.addView(label("To Download and Install this apk on your Android device from which you want to control this TV", 22f, "#777777", justify = true))
        left.addView(label("You'll get tutorial on how to use this app on ATC - Phone App.", 16f, "#777777").apply { setPadding(0, px(26f), 0, 0) })
        left.addView(label("All QR are same, placed at different area for faulty screens.", 15f, "#777777").apply { setPadding(0, px(22f), 0, 0) })
        row.addView(left, LinearLayout.LayoutParams(px(384f), match))

        val mid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL }
        mid.addView(ImageView(this).apply {
            setImageResource(R.drawable.qr_phone); scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.WHITE)
        }, LinearLayout.LayoutParams(px(267f), px(267f)))
        mid.addView(label("Made with \uD83D\uDC9C by DS Yadav", 12f, "#777777").apply { gravity = Gravity.CENTER; setPadding(0, px(8f), 0, 0) })
        row.addView(mid, LinearLayout.LayoutParams(px(267f), wrap))

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(px(20f), px(58f), px(18f), 0) }
        right.addView(label("Your parents' TV troubles are now your problem... remotely.", 17f, "#777777", justify = true))
        row.addView(right, LinearLayout.LayoutParams(px(394f), wrap))

        root.addView(row, LinearLayout.LayoutParams(match, wrap).apply { topMargin = px(53f) })

        // pushes the long paragraph to the bottom
        root.addView(View(this), LinearLayout.LayoutParams(match, 0, 1f))
        root.addView(label("Created by someone who got tired of hearing 'Beta, TV nahi chal raha!' " +
            "Anywhere TV lets you control your television remotely, so your not-so-tech-friendly loved ones never miss their favourite episodes, " +
            "and you never have to explain which button to press over a video call again.", 13f, "#BDBDBD", justify = true).apply { setPadding(0, 0, 0, px(2f)) },
            LinearLayout.LayoutParams(match, wrap))

        // the same QR again in four other places, in case part of the screen is faulty
        val frame = FrameLayout(this)
        frame.addView(root, FrameLayout.LayoutParams(match, match))
        for ((x, y, size) in listOf(Triple(765f, 50f, 85f), Triple(885f, 235f, 112f), Triple(62f, 428f, 113f), Triple(680f, 428f, 112f))) {
            frame.addView(
                ImageView(this).apply { setImageResource(R.drawable.qr_phone); scaleType = ImageView.ScaleType.FIT_CENTER; setBackgroundColor(Color.WHITE) },
                FrameLayout.LayoutParams(px(size), px(size), Gravity.TOP or Gravity.START).apply { leftMargin = px(x); topMargin = px(y) })
        }
        setContentView(frame)
    }
}
