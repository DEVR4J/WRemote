package com.example.tvagent

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import org.json.JSONArray
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.File

/** Checks GitHub Releases for a newer build, downloads it and starts the installer. */
object Updater {
    const val REPO = "OWNER/REPO"   // filled in by the build workflow
    const val BUILD = 0             // filled in by the build workflow
    const val APK_NAME = "ATC-TV.apk"
    class Info(val tag: String, val build: Int, val url: String)
    @Volatile var status = ""
    @Volatile var replaceNext = false   // set when Android says the signing keys differ
    @Volatile var info: Info? = null
    @Volatile private var busy = false
    private val http = OkHttpClient()

    fun check(ctx: Context, autoInstall: Boolean) {
        if (REPO.startsWith("OWNER")) { status = "Updates are not set up in this build"; Agent.ui(); return }
        if (busy) return
        busy = true; status = "Checking for updates..."; Agent.ui()
        try {
            val req = Request.Builder().url("https://api.github.com/repos/$REPO/releases?per_page=20")
                .header("Accept", "application/vnd.github+json").header("User-Agent", "ATC-Updater").build()
            http.newCall(req).execute().use { r -> readRelease(r) }
        } catch (t: Throwable) { status = "Update check failed: ${t.message}".take(120) }
        busy = false; Agent.ui()
        if (info != null && autoInstall) installLatest(ctx)
    }

    /** Looks through the recent releases for the newest one that contains this app's APK. */
    private fun readRelease(r: Response) {
        if (r.code == 404) { status = "No releases found in $REPO (is the repo public?)"; info = null; return }
        if (!r.isSuccessful) { status = "Update check failed (${r.code})"; return }
        val arr = JSONArray(r.body!!.string())
        var best: Info? = null
        for (k in 0 until arr.length()) {
            val j = arr.getJSONObject(k)
            if (j.optBoolean("draft") || j.optBoolean("prerelease")) continue
            val tag = j.getString("tag_name")
            val n = Regex("(\\d+)$").find(tag)?.value?.toIntOrNull() ?: 0
            val assets = j.getJSONArray("assets")
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.getString("name") == APK_NAME && (best == null || n > best.build)) best = Info(tag, n, a.getString("browser_download_url"))
            }
        }
        val b = best
        if (b == null) { info = null; status = "No $APK_NAME in the releases of $REPO" }
        else if (b.build > BUILD) { info = b; status = "Update available: ${b.tag}" }
        else { info = null; status = "Up to date (build $BUILD)" }
    }

    fun installLatest(ctx: Context) {
        val i = info ?: return
        if (busy) return
        busy = true
        try {
            val out = File(ctx.getExternalFilesDir(null) ?: ctx.cacheDir, "update.apk")
            val req = Request.Builder().url(i.url).header("User-Agent", "ATC-Updater").build()
            http.newCall(req).execute().use { r -> saveBody(r, out) }
            if (out.exists() && out.length() > 0) {
                if (replaceNext) {
                    replaceNext = false
                    if (Agent.adbOk && replaceViaAdb(ctx, out)) status = "Replacing the app... it restarts in a few seconds"
                    else { openUninstall(ctx); status = "Uninstall this app, then install the newest release (scan the QR code)" }
                    busy = false; Agent.ui(); return
                }
                val bad = problem(ctx, out)
                if (bad != null) {
                    if (bad.contains("different signing key")) {
                        replaceNext = true
                        status = if (Agent.adbOk) "Different signing key. Tap INSTALL UPDATE again to replace the app (code and server will reset)."
                                 else "Different signing key. Tap INSTALL UPDATE again to uninstall this app, then install the newest release."
                    } else status = bad
                    busy = false; Agent.ui(); return
                }
                status = "Installing..."; Agent.ui()
                if (Agent.adbOk && Agent.installViaAdb(out.path)) status = "Updated. Open the app again."
                else if (install(ctx, out)) status = "Confirm the update in the installer window"
            }
        } catch (t: Throwable) { status = "Update failed: ${t.message}".take(120) }
        busy = false; Agent.ui()
    }

    private fun saveBody(r: Response, out: File) {
        if (!r.isSuccessful) { status = "Download failed (${r.code})"; return }
        val body = r.body ?: return
        val total = body.contentLength(); var got = 0L; var last = -1
        body.byteStream().use { inp ->
            out.outputStream().use { o ->
                val buf = ByteArray(32768)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n); got += n
                    if (total > 0) { val pct = (got * 100 / total).toInt(); if (pct != last) { last = pct; status = "Downloading $pct%"; Agent.ui() } }
                }
            }
        }
    }

    /** Says why Android would refuse this file as an update, or null when it looks fine. */
    private fun problem(ctx: Context, apk: File): String? {
        return try {
            val pm = ctx.packageManager
            val flag = if (Build.VERSION.SDK_INT >= 28) PackageManager.GET_SIGNING_CERTIFICATES else 0
            val arch = pm.getPackageArchiveInfo(apk.path, flag) ?: return "The downloaded file is not a valid app"
            val cur = pm.getPackageInfo(ctx.packageName, flag)
            @Suppress("DEPRECATION")
            if (arch.versionCode < cur.versionCode) return "The downloaded version (${arch.versionCode}) is older than the installed one (${cur.versionCode}). Uninstall this app once and install the newest release."
            if (Build.VERSION.SDK_INT >= 28) {
                val a = arch.signingInfo?.apkContentsSigners?.map { it.toCharsString() }?.toSet()
                val c = cur.signingInfo?.apkContentsSigners?.map { it.toCharsString() }?.toSet()
                if (a != null && c != null && a != c)
                    return "The new version has a different signing key, so Android cannot update over this one. Uninstall this app once, then install the newest release (scan the QR code)."
            }
            null
        } catch (e: Throwable) { null }
    }

    /** Uninstalls this app and installs the new file in one go (needs USB debugging). Settings are lost. */
    private fun replaceViaAdb(ctx: Context, apk: File): Boolean {
        val pkg = ctx.packageName
        return Agent.runShell("cp \"${apk.path}\" /data/local/tmp/atc_update.apk && chmod 644 /data/local/tmp/atc_update.apk && " +
            "nohup sh -c 'sleep 1; pm uninstall $pkg; pm install -r /data/local/tmp/atc_update.apk; am start -n $pkg/.MainActivity' > /dev/null 2>&1 &")
    }

    private fun openUninstall(ctx: Context) {
        try { ctx.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (e: Exception) { status = "Uninstall this app from Settings > Apps, then install the newest release" }
    }

    private fun install(ctx: Context, apk: File): Boolean {
        // Android needs "Install unknown apps" switched on for this app first.
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            try {
                ctx.startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                status = "Allow 'Install unknown apps' for this app, then press Install update again"
                return false
            } catch (e: Exception) { /* this TV has no such screen: try the installer anyway */ }
        }
        val pi = ctx.packageManager.packageInstaller
        val id = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
        pi.openSession(id).use { s ->
            apk.inputStream().use { inp -> s.openWrite("app.apk", 0, apk.length()).use { o -> inp.copyTo(o); s.fsync(o) } }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pending = PendingIntent.getBroadcast(ctx, id, Intent(ctx, InstallReceiver::class.java), flags)
            s.commit(pending.intentSender)
        }
        return true
    }
}

/** Receives the installer's answer and opens its confirmation window. */
class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) { confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(confirm) }
            }
            PackageInstaller.STATUS_SUCCESS -> { Updater.status = "Updated"; Agent.ui() }
            else -> {
                val m = i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE) ?: ""
                if (m.contains("signatures do not match", true) || m.contains("UPDATE_INCOMPATIBLE", true)) {
                    Updater.replaceNext = true
                    Updater.status = if (Agent.adbOk) "Different signing key. Tap INSTALL UPDATE again to replace the app (code and server will reset)."
                                     else "Different signing key. Tap INSTALL UPDATE again to uninstall this app, then install the newest release."
                } else Updater.status = "Install failed: $m".take(120)
                Agent.ui()
            }
        }
    }
}
