package com.example.tvagent

import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageInstaller
import android.os.Build
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import org.json.JSONObject
import java.io.File

/** Checks GitHub Releases for a newer build, downloads it and starts the installer. */
object Updater {
    const val REPO = "OWNER/REPO"   // filled in by the build workflow
    const val BUILD = 0             // filled in by the build workflow
    class Info(val tag: String, val build: Int, val url: String)
    @Volatile var status = ""
    @Volatile var info: Info? = null
    @Volatile private var busy = false
    private val http = OkHttpClient()

    fun check(ctx: Context, autoInstall: Boolean) {
        if (REPO.startsWith("OWNER")) { status = "Updates are not set up in this build"; Agent.ui(); return }
        if (busy) return
        busy = true; status = "Checking for updates..."; Agent.ui()
        try {
            val req = Request.Builder().url("https://api.github.com/repos/$REPO/releases/latest")
                .header("Accept", "application/vnd.github+json").header("User-Agent", "ATC-Updater").build()
            http.newCall(req).execute().use { r -> readRelease(r) }
        } catch (t: Throwable) { status = "Update check failed: ${t.message}".take(120) }
        busy = false; Agent.ui()
        if (info != null && autoInstall) installLatest(ctx)
    }

    private fun readRelease(r: Response) {
        if (r.code == 404) { status = "No releases yet"; info = null; return }
        if (!r.isSuccessful) { status = "Update check failed (${r.code})"; return }
        val j = JSONObject(r.body!!.string())
        val tag = j.getString("tag_name")
        val n = Regex("(\\d+)$").find(tag)?.value?.toIntOrNull() ?: 0
        val assets = j.getJSONArray("assets")
        var url = ""
        for (i in 0 until assets.length()) {
            val a = assets.getJSONObject(i)
            if (a.getString("name").endsWith(".apk")) { url = a.getString("browser_download_url"); break }
        }
        if (n > BUILD && url.isNotEmpty()) { info = Info(tag, n, url); status = "Update available: $tag" }
        else { info = null; status = "Up to date (build $BUILD)" }
    }

    fun installLatest(ctx: Context) {
        val i = info ?: return
        if (busy) return
        busy = true
        try {
            val out = File(ctx.getExternalFilesDir(null) ?: ctx.cacheDir, "update.apk")
            val req = Request.Builder().url(i.url).header("User-Agent", "ATC-Updater").build()
            http.newCall(req).execute().use { r -> saveBody(r, out) }
            if (out.exists() && out.length() > 0) {
                status = "Installing..."; Agent.ui()
                if (Agent.adbOk && Agent.installViaAdb(out.path)) status = "Updated. Open the app again."
                else { install(ctx, out); status = "Confirm the update in the installer window" }
            }
        } catch (t: Throwable) { status = "Update failed: ${t.message}".take(120) }
        busy = false; Agent.ui()
    }

    private fun saveBody(r: Response, out: File) {
        if (!r.isSuccessful) { status = "Download failed (${r.code})"; return }
        val body = r.body ?: return
        val total = body.contentLength(); var got = 0L; var last = -1
        body.byteStream().use { inp ->
            out.outputStream().use { o ->
                val buf = ByteArray(32768)
                while (true) {
                    val n = inp.read(buf)
                    if (n < 0) break
                    o.write(buf, 0, n); got += n
                    if (total > 0) { val pct = (got * 100 / total).toInt(); if (pct != last) { last = pct; status = "Downloading $pct%"; Agent.ui() } }
                }
            }
        }
    }

    private fun install(ctx: Context, apk: File) {
        val pi = ctx.packageManager.packageInstaller
        val id = pi.createSession(PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL))
        pi.openSession(id).use { s ->
            apk.inputStream().use { inp -> s.openWrite("app.apk", 0, apk.length()).use { o -> inp.copyTo(o); s.fsync(o) } }
            val flags = PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0)
            val pending = PendingIntent.getBroadcast(ctx, id, Intent(ctx, InstallReceiver::class.java), flags)
            s.commit(pending.intentSender)
        }
    }
}

/** Receives the installer's answer and opens its confirmation window. */
class InstallReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        when (i.getIntExtra(PackageInstaller.EXTRA_STATUS, -1)) {
            PackageInstaller.STATUS_PENDING_USER_ACTION -> {
                @Suppress("DEPRECATION")
                val confirm = i.getParcelableExtra<Intent>(Intent.EXTRA_INTENT)
                if (confirm != null) { confirm.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(confirm) }
            }
            PackageInstaller.STATUS_SUCCESS -> { Updater.status = "Updated"; Agent.ui() }
            else -> { Updater.status = "Install failed: ${i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE)}".take(120); Agent.ui() }
        }
    }
}
