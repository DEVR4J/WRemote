package com.example.tvagent

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** List of files received from the phone, newest first. Tap one to open it. */
class FilesActivity : Activity() {
    private fun size(b: Long): String = when {
        b >= 1_048_576 -> "%.1f MB".format(b / 1_048_576.0)
        b >= 1024 -> "%.0f KB".format(b / 1024.0)
        else -> "$b B"
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_files)
        val list = findViewById<ListView>(R.id.fileList)
        val empty = findViewById<TextView>(R.id.emptyText)
        val items = Received.all(this)
        empty.visibility = if (items.isEmpty()) View.VISIBLE else View.GONE
        val fmt = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
        list.adapter = object : BaseAdapter() {
            override fun getCount() = items.size
            override fun getItem(p: Int) = items[p]
            override fun getItemId(p: Int) = p.toLong()
            override fun getView(p: Int, v: View?, parent: ViewGroup): View {
                val row = v ?: layoutInflater.inflate(R.layout.row_file, parent, false)
                val item = items[p]
                row.findViewById<TextView>(R.id.fileName).text = item.name
                row.findViewById<TextView>(R.id.fileInfo).text = fmt.format(Date(item.time)) + "     " + size(item.size)
                row.findViewById<TextView>(R.id.fileWhere).text = item.where
                return row
            }
        }
        list.setOnItemClickListener { _, _, p, _ ->
            val err = Received.open(this, items[p])
            if (err != null) Toast.makeText(this, err, Toast.LENGTH_LONG).show()
        }
    }
}
