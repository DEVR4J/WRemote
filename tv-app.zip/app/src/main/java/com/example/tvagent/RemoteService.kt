package com.example.tvagent

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Lets the app press Back/Home, tap, swipe and move focus without ADB. User enables it once in Accessibility settings. */
class RemoteService : AccessibilityService() {
    companion object { @Volatile var instance: RemoteService? = null }
    override fun onServiceConnected() { instance = this; Agent.ui() }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; Agent.ui(); return super.onUnbind(intent) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun back() { performGlobalAction(GLOBAL_ACTION_BACK) }
    fun home() { performGlobalAction(GLOBAL_ACTION_HOME) }
    fun power() { performGlobalAction(GLOBAL_ACTION_POWER_DIALOG) }
    fun tap(x: Float, y: Float) { swipe(x, y, x, y, 60) }
    fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long) {
        val p = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, ms)).build(), null, null)
    }

    private fun focused(): AccessibilityNodeInfo? {
        val r = rootInActiveWindow ?: return null
        return r.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: r.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
    }
    fun recents() { performGlobalAction(GLOBAL_ACTION_RECENTS) }
    private fun curText(n: AccessibilityNodeInfo): String =
        if (android.os.Build.VERSION.SDK_INT >= 26 && n.isShowingHintText) "" else (n.text?.toString() ?: "")
    private fun setText(n: AccessibilityNodeInfo, t: String): Boolean {
        val a = Bundle(); a.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t)
        return n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, a)
    }
    /** Keyboard: append text to the focused text field. */
    fun typeText(s: String): Boolean { val n = focused() ?: return false; if (!n.isEditable) return false; return setText(n, curText(n) + s) }
    fun del(): Boolean { val n = focused() ?: return false; if (!n.isEditable) return false; return setText(n, curText(n).dropLast(1)) }
    fun enter() {
        val n = focused()
        if (n != null && android.os.Build.VERSION.SDK_INT >= 30) { n.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id); return }
        ok()
    }
    /** D-pad: move focus (View.FOCUS_UP/DOWN/LEFT/RIGHT). */
    fun move(dir: Int) {
        val r = rootInActiveWindow ?: return
        val next = (focused() ?: r).focusSearch(dir)
        next?.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
    }
    /** OK button: click the focused item (or its nearest clickable parent). */
    fun ok() {
        var n = focused()
        while (n != null) {
            if (n.isClickable && n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return
            n = n.parent
        }
    }
}
