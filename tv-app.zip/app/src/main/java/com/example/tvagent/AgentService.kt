package com.example.tvagent

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder

// Foreground service keeps the agent alive (and satisfies MediaProjection rules on Android 10+).
class AgentService : Service() {
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("agent", "Remote Agent", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "agent").setContentTitle("Remote access active")
            .setSmallIcon(android.R.drawable.ic_media_play).build()
        if (Build.VERSION.SDK_INT >= 29 && Agent.projection != null)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
        try { Agent.start(this) } catch (t: Throwable) { Agent.note = "Start failed: ${t.javaClass.simpleName}: ${t.message}"; Agent.ui() }
        return START_STICKY
    }
}
