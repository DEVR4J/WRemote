package com.example.tvagent

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import dadb.AdbKeyPair
import dadb.Dadb
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.java_websocket.WebSocket as LanSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.*
import java.io.File
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** TV side: home Wi-Fi server + optional internet server link + ADB control + WebRTC screen mirror. */
object Agent {
    const val LAN_PORT = 8765
    var onUi: () -> Unit = {}
    var projection: Intent? = null
    var id: String? = null
    var server = ""            // optional internet server, set inside the app
    var cloud = "none"         // none | offline | online
    var adbOk = false
    var lanIp = ""
    var started = false
    val hasPin: Boolean get() = pin != null

    private var pin: String? = null
    private lateinit var ctx: Context
    private val io = Executors.newSingleThreadExecutor()
    private val http = OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build()
    private var ws: WebSocket? = null
    private var lan: WebSocketServer? = null
    private var lanConn: LanSocket? = null
    private var via = "cloud"
    private var lanFails = 0
    private var lanLock = 0L
    private var adb: Dadb? = null
    private var factory: PeerConnectionFactory? = null
    private var egl: EglBase? = null
    private var track: VideoTrack? = null
    private var pc: PeerConnection? = null
    private var dc: DataChannel? = null

    private fun prefs() = ctx.getSharedPreferences("agent", Context.MODE_PRIVATE)
    fun ui() { lanIp = localIp(); onUi() }

    fun load(c: Context) {
        ctx = c.applicationContext
        server = prefs().getString("server", "") ?: ""
        pin = prefs().getString("pin", null)
        if (server.isNotEmpty() && cloud == "none") cloud = "offline"
    }

    fun normalize(input: String): String {
        val t = input.trim().removeSuffix("/")
        return when {
            t.isEmpty() -> ""
            t.startsWith("wss://") || t.startsWith("ws://") -> t
            t.startsWith("https://") -> "wss://" + t.removePrefix("https://")
            t.startsWith("http://") -> "ws://" + t.removePrefix("http://")
            else -> "wss://$t"
        }
    }

    fun setPin(p: String) { pin = p; prefs().edit().putString("pin", p).apply(); pushPin(); ui() }
    private fun pushPin() { pin?.let { ws?.send(JSONObject().put("type", "set-pin").put("pin", it).toString()) } }

    fun saveServer(s: String) {
        server = s; prefs().edit().putString("server", s).apply()
        cloud = if (s.isEmpty()) "none" else "offline"
        if (started) { if (ws != null) ws?.close(1000, "changed") else connectWs() }
        ui()
    }

    fun start(c: Context) {
        if (started) return
        started = true; load(c)
        initRtc(); connectAdb(); startLan(); connectWs()
    }

    // ---------- ADB (loopback; one-time "Allow debugging" prompt on the TV) ----------
    private fun connectAdb() = Thread {
        while (adb == null) {
            try {
                val priv = File(ctx.filesDir, "adbkey"); val pub = File(ctx.filesDir, "adbkey.pub")
                if (!priv.exists()) AdbKeyPair.generate(priv, pub)
                val d = Dadb.create("127.0.0.1", 5555, AdbKeyPair.read(priv, pub))
                d.shell("echo ok"); adb = d; adbOk = true; ui()
            } catch (e: Exception) { adbOk = false; ui(); Thread.sleep(3000) }
        }
    }.start()

    private fun sh(cmd: String) = io.execute { try { adb?.shell(cmd) } catch (_: Exception) { adb = null; adbOk = false; ui(); connectAdb() } }

    private val keys = mapOf("DPAD_UP" to 19, "DPAD_DOWN" to 20, "DPAD_LEFT" to 21, "DPAD_RIGHT" to 22,
        "DPAD_CENTER" to 23, "BACK" to 4, "HOME" to 3, "VOLUME_UP" to 24, "VOLUME_DOWN" to 25,
        "MUTE" to 164, "MEDIA_PLAY_PAUSE" to 85, "POWER" to 26)

    private fun handle(d: JSONObject) {
        val dm = ctx.resources.displayMetrics
        fun px(v: Double, max: Int) = (v * max).toInt()
        when (d.getString("t")) {
            "key" -> keys[d.getString("k")]?.let { sh("input keyevent $it") }
            "launch" -> sh("monkey -p ${d.getString("pkg")} -c android.intent.category.LEANBACK_LAUNCHER 1")
            "tap" -> sh("input tap ${px(d.getDouble("x"), dm.widthPixels)} ${px(d.getDouble("y"), dm.heightPixels)}")
            "swipe" -> sh("input swipe ${px(d.getDouble("x1"), dm.widthPixels)} ${px(d.getDouble("y1"), dm.heightPixels)} " +
                "${px(d.getDouble("x2"), dm.widthPixels)} ${px(d.getDouble("y2"), dm.heightPixels)} 250")
        }
    }

    // ---------- Home Wi-Fi mode: the TV is its own server ----------
    private fun localIp(): String = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it is Inet4Address && it.isSiteLocalAddress }?.hostAddress ?: ""
    } catch (e: Exception) { "" }

    private fun err(msg: String) = JSONObject().put("type", "error").put("msg", msg).toString()

    private fun startLan() {
        try {
            lan = object : WebSocketServer(InetSocketAddress(LAN_PORT)) {
                override fun onOpen(c: LanSocket, h: ClientHandshake) {}
                override fun onClose(c: LanSocket, code: Int, reason: String?, remote: Boolean) { if (c === lanConn) lanConn = null }
                override fun onMessage(c: LanSocket, message: String) { try { lanMessage(c, JSONObject(message)) } catch (_: Exception) {} }
                override fun onError(c: LanSocket?, e: Exception?) {}
                override fun onStart() {}
            }.also { it.isReuseAddr = true; it.start() }
        } catch (e: Exception) { }
        ui()
    }

    private fun lanMessage(c: LanSocket, m: JSONObject) {
        when (m.optString("type")) {
            "connect" -> {
                if (System.currentTimeMillis() < lanLock) { c.send(err("Locked, try again in a few minutes")); return }
                val saved = pin
                if (saved == null || !MessageDigest.isEqual(saved.toByteArray(), m.optString("pin").toByteArray())) {
                    if (++lanFails >= 5) { lanFails = 0; lanLock = System.currentTimeMillis() + 10 * 60000 }
                    c.send(err("Wrong code")); return
                }
                lanFails = 0; lanConn = c; via = "lan"
                c.send(JSONObject().put("type", "connected").put("ice", JSONArray()).toString())
                io.execute { startPeer(JSONArray()) }
            }
            "sig" -> if (c === lanConn) io.execute { onSig(m.getJSONObject("data")) }
        }
    }

    // ---------- Internet mode (optional server) ----------
    private fun connectWs() {
        if (server.isEmpty()) { cloud = "none"; ui(); return }
        val p = prefs()
        val req = try { Request.Builder().url(server).build() } catch (e: Exception) { cloud = "offline"; ui(); return }
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) {
                w.send(JSONObject().put("type", "tv-hello").put("id", p.getString("id", null)).put("key", p.getString("key", null)).toString())
            }
            override fun onMessage(w: WebSocket, t: String) {
                val m = JSONObject(t)
                when (m.getString("type")) {
                    "tv-ok" -> {
                        id = m.getString("id"); p.edit().putString("id", id).putString("key", m.getString("key")).apply()
                        cloud = "online"; if (!m.getBoolean("hasPin")) pushPin(); ui()
                    }
                    "peer" -> { via = "cloud"; io.execute { startPeer(m.getJSONArray("ice")) } }
                    "sig" -> if (via == "cloud") io.execute { onSig(m.getJSONObject("data")) }
                }
            }
            override fun onFailure(w: WebSocket, e: Throwable, r: Response?) { retry() }
            override fun onClosed(w: WebSocket, c: Int, r: String) { retry() }
            fun retry() { cloud = if (server.isEmpty()) "none" else "offline"; ui(); Thread.sleep(3000); connectWs() }
        })
    }

    private fun sig(o: JSONObject) {
        val msg = JSONObject().put("type", "sig").put("data", o).toString()
        if (via == "lan") lanConn?.send(msg) else ws?.send(msg)
    }

    // ---------- WebRTC (same for both modes) ----------
    private fun initRtc() {
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(ctx).createInitializationOptions())
        egl = EglBase.create()
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl!!.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl!!.eglBaseContext)).createPeerConnectionFactory()
    }

    private fun ensureTrack() {
        val proj = projection ?: return
        if (track != null) return
        val cap = ScreenCapturerAndroid(proj, object : MediaProjection.Callback() {})
        val src = factory!!.createVideoSource(true)
        cap.initialize(SurfaceTextureHelper.create("cap", egl!!.eglBaseContext), ctx, src.capturerObserver)
        cap.startCapture(1280, 720, 30)
        track = factory!!.createVideoTrack("screen", src)
    }

    private fun startPeer(ice: JSONArray) {
        pc?.close()
        val servers = (0 until ice.length()).map {
            val o = ice.getJSONObject(it)
            val b = PeerConnection.IceServer.builder(o.getString("urls"))
            if (o.has("username")) b.setUsername(o.getString("username")).setPassword(o.getString("credential"))
            b.createIceServer()
        }
        val cfg = PeerConnection.RTCConfiguration(servers).apply { sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN }
        pc = factory!!.createPeerConnection(cfg, object : Obs() {
            override fun onIceCandidate(c: IceCandidate) =
                sig(JSONObject().put("ice", JSONObject().put("candidate", c.sdp).put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex)))
        })!!
        ensureTrack(); track?.let { pc!!.addTrack(it, listOf("s")) }
        dc = pc!!.createDataChannel("ctl", DataChannel.Init())
        dc!!.registerObserver(object : DataChannel.Observer {
            override fun onMessage(b: DataChannel.Buffer) {
                val bytes = ByteArray(b.data.remaining()).also { b.data.get(it) }
                handle(JSONObject(String(bytes)))
            }
            override fun onBufferedAmountChange(l: Long) {}
            override fun onStateChange() {}
        })
        pc!!.createOffer(object : Sdp() {
            override fun onCreateSuccess(d: SessionDescription) {
                pc!!.setLocalDescription(Sdp(), d)
                sig(JSONObject().put("sdp", d.description).put("sdpType", "offer"))
            }
        }, MediaConstraints())
    }

    private fun onSig(d: JSONObject) {
        if (d.has("sdp")) pc?.setRemoteDescription(Sdp(), SessionDescription(SessionDescription.Type.ANSWER, d.getString("sdp")))
        else if (d.has("ice")) d.getJSONObject("ice").let { pc?.addIceCandidate(IceCandidate(it.getString("sdpMid"), it.getInt("sdpMLineIndex"), it.getString("candidate"))) }
    }

    open class Sdp : SdpObserver {
        override fun onCreateSuccess(d: SessionDescription) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(e: String?) {}
        override fun onSetFailure(e: String?) {}
    }
    open class Obs : PeerConnection.Observer {
        override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
        override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {}
        override fun onIceConnectionReceivingChange(b: Boolean) {}
        override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
        override fun onIceCandidate(c: IceCandidate) {}
        override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
        override fun onAddStream(s: MediaStream?) {}
        override fun onRemoveStream(s: MediaStream?) {}
        override fun onDataChannel(d: DataChannel?) {}
        override fun onRenegotiationNeeded() {}
        override fun onAddTrack(r: RtpReceiver?, s: Array<out MediaStream>?) {}
    }
}
