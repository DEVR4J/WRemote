package com.example.tvagent

import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjection
import dadb.AdbKeyPair
import dadb.Dadb
import okhttp3.*
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.*
import java.io.File
import java.util.concurrent.Executors

/** Everything the TV does: cloud link, ADB control, WebRTC screen mirror. */
object Agent {
    const val SERVER = "wss://YOUR-APP.onrender.com" // same URL as phone app
    var onUi: (String, String?, Boolean) -> Unit = { _, _, _ -> }
    var cloud = "offline"; var adbOk = false
    fun ui() = onUi(cloud, id, adbOk)
    var projection: Intent? = null
    var id: String? = null

    private lateinit var ctx: Context
    private val io = Executors.newSingleThreadExecutor()
    private val http = OkHttpClient.Builder().pingInterval(25, java.util.concurrent.TimeUnit.SECONDS).build()
    private var ws: WebSocket? = null
    private var adb: Dadb? = null
    private var factory: PeerConnectionFactory? = null
    private var egl: EglBase? = null
    private var track: VideoTrack? = null
    private var pc: PeerConnection? = null
    var started = false
    private var dc: DataChannel? = null

    fun start(c: Context) {
        if (started) return; started = true; ctx = c.applicationContext
        initRtc(); connectAdb(); connectWs()
    }

    fun setPin(pin: String) { ws?.send(JSONObject().put("type", "set-pin").put("pin", pin).toString()) }

    // ---------- ADB (loopback; one-time "Allow debugging" prompt on the TV) ----------
    private fun connectAdb() = Thread {
        while (adb == null) {
            try {
                val priv = File(ctx.filesDir, "adbkey"); val pub = File(ctx.filesDir, "adbkey.pub")
                if (!priv.exists()) AdbKeyPair.generate(priv, pub)
                val d = Dadb.create("127.0.0.1", 5555, AdbKeyPair.read(priv, pub))
                d.shell("echo ok"); adb = d; adbOk = true; ui()
            } catch (e: Exception) { adbOk = false; ui(); Thread.sleep(3000) }
        }
    }.start()

    private fun sh(cmd: String) = io.execute { try { adb?.shell(cmd) } catch (_: Exception) { adb = null; adbOk = false; ui(); connectAdb() } }

    private val keys = mapOf("DPAD_UP" to 19, "DPAD_DOWN" to 20, "DPAD_LEFT" to 21, "DPAD_RIGHT" to 22,
        "DPAD_CENTER" to 23, "BACK" to 4, "HOME" to 3, "VOLUME_UP" to 24, "VOLUME_DOWN" to 25,
        "MUTE" to 164, "MEDIA_PLAY_PAUSE" to 85, "POWER" to 26)

    private fun handle(d: JSONObject) {
        val dm = ctx.resources.displayMetrics
        fun px(v: Double, max: Int) = (v * max).toInt()
        when (d.getString("t")) {
            "key" -> keys[d.getString("k")]?.let { sh("input keyevent $it") }
            "launch" -> sh("monkey -p ${d.getString("pkg")} -c android.intent.category.LEANBACK_LAUNCHER 1")
            "tap" -> sh("input tap ${px(d.getDouble("x"), dm.widthPixels)} ${px(d.getDouble("y"), dm.heightPixels)}")
            "swipe" -> sh("input swipe ${px(d.getDouble("x1"), dm.widthPixels)} ${px(d.getDouble("y1"), dm.heightPixels)} " +
                "${px(d.getDouble("x2"), dm.widthPixels)} ${px(d.getDouble("y2"), dm.heightPixels)} 250")
        }
    }

    // ---------- Cloud signaling ----------
    private fun connectWs() {
        val p = ctx.getSharedPreferences("agent", Context.MODE_PRIVATE)
        ws = http.newWebSocket(Request.Builder().url(SERVER).build(), object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) {
                w.send(JSONObject().put("type", "tv-hello").put("id", p.getString("id", null)).put("key", p.getString("key", null)).toString())
            }
            override fun onMessage(w: WebSocket, t: String) {
                val m = JSONObject(t)
                when (m.getString("type")) {
                    "tv-ok" -> { id = m.getString("id"); p.edit().putString("id", id).putString("key", m.getString("key")).apply()
                        cloud = if (m.getBoolean("hasPin")) "ready" else "needpin"; ui() }
                    "pin-ok" -> { cloud = "ready"; ui() }
                    "peer" -> io.execute { startPeer(m.getJSONArray("ice")) }
                    "sig" -> io.execute { onSig(m.getJSONObject("data")) }
                }
            }
            override fun onFailure(w: WebSocket, e: Throwable, r: Response?) { cloud = "offline"; ui(); Thread.sleep(3000); connectWs() }
            override fun onClosed(w: WebSocket, c: Int, r: String) { Thread.sleep(3000); connectWs() }
        })
    }
    private fun sig(o: JSONObject) { ws?.send(JSONObject().put("type", "sig").put("data", o).toString()) }

    // ---------- WebRTC ----------
    private fun initRtc() {
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(ctx).createInitializationOptions())
        egl = EglBase.create()
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl!!.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl!!.eglBaseContext)).createPeerConnectionFactory()
    }

    private fun ensureTrack() {
        val proj = projection ?: return
        if (track != null) return
        val cap = ScreenCapturerAndroid(proj, object : MediaProjection.Callback() {})
        val src = factory!!.createVideoSource(true)
        cap.initialize(SurfaceTextureHelper.create("cap", egl!!.eglBaseContext), ctx, src.capturerObserver)
        cap.startCapture(1280, 720, 30)
        track = factory!!.createVideoTrack("screen", src)
    }

    private fun startPeer(ice: JSONArray) {
        pc?.close()
        val servers = (0 until ice.length()).map {
            val o = ice.getJSONObject(it)
            val b = PeerConnection.IceServer.builder(o.getString("urls"))
            if (o.has("username")) b.setUsername(o.getString("username")).setPassword(o.getString("credential"))
            b.createIceServer()
        }
        val cfg = PeerConnection.RTCConfiguration(servers).apply { sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN }
        pc = factory!!.createPeerConnection(cfg, object : Obs() {
            override fun onIceCandidate(c: IceCandidate) =
                sig(JSONObject().put("ice", JSONObject().put("candidate", c.sdp).put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex)))
        })!!
        ensureTrack(); track?.let { pc!!.addTrack(it, listOf("s")) }
        dc = pc!!.createDataChannel("ctl", DataChannel.Init())
        dc!!.registerObserver(object : DataChannel.Observer {
            override fun onMessage(b: DataChannel.Buffer) {
                val bytes = ByteArray(b.data.remaining()).also { b.data.get(it) }
                handle(JSONObject(String(bytes)))
            }
            override fun onBufferedAmountChange(l: Long) {}
            override fun onStateChange() {}
        })
        pc!!.createOffer(object : Sdp() {
            override fun onCreateSuccess(d: SessionDescription) {
                pc!!.setLocalDescription(Sdp(), d)
                sig(JSONObject().put("sdp", d.description).put("sdpType", "offer"))
            }
        }, MediaConstraints())
    }

    private fun onSig(d: JSONObject) {
        if (d.has("sdp")) pc?.setRemoteDescription(Sdp(), SessionDescription(SessionDescription.Type.ANSWER, d.getString("sdp")))
        else if (d.has("ice")) d.getJSONObject("ice").let { pc?.addIceCandidate(IceCandidate(it.getString("sdpMid"), it.getInt("sdpMLineIndex"), it.getString("candidate"))) }
    }

    open class Sdp : SdpObserver {
        override fun onCreateSuccess(d: SessionDescription) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(e: String?) {}
        override fun onSetFailure(e: String?) {}
    }
    open class Obs : PeerConnection.Observer {
        override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
        override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {}
        override fun onIceConnectionReceivingChange(b: Boolean) {}
        override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
        override fun onIceCandidate(c: IceCandidate) {}
        override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
        override fun onAddStream(s: MediaStream?) {}
        override fun onRemoveStream(s: MediaStream?) {}
        override fun onDataChannel(d: DataChannel?) {}
        override fun onRenegotiationNeeded() {}
        override fun onAddTrack(r: RtpReceiver?, s: Array<out MediaStream>?) {}
    }
}
