package com.example.tvagent

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.media.projection.MediaProjection
import android.view.KeyEvent
import android.view.View
import dadb.AdbKeyPair
import dadb.Dadb
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.java_websocket.WebSocket as LanSocket
import org.java_websocket.handshake.ClientHandshake
import org.java_websocket.server.WebSocketServer
import org.json.JSONArray
import org.json.JSONObject
import org.webrtc.*
import java.io.File
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.security.MessageDigest
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/** TV side: home Wi-Fi server + optional internet server link + ADB control + WebRTC screen mirror. */
object Agent {
    const val LAN_PORT = 8765
    var onUi: () -> Unit = {}
    var projection: Intent? = null
    var id: String? = null
    var server = ""            // optional internet server, set inside the app
    var cloud = "none"         // none | offline | online
    var adbOk = false
    var lanIp = ""
    var started = false
    var note = ""        // last non-fatal problem, shown on screen
    var lastCrash = ""   // stack trace of previous crash, shown on screen
    var mirror = true    // screen mirroring on/off (auto-off after a crash)
    var lastTrace = ""   // steps reached before the app last died
    private fun traceFile() = File(ctx.filesDir, "trace.txt")
    private fun resetTrace() { try { traceFile().writeText("") } catch (ignored: Throwable) {} }
    private fun trace(s: String) { try { traceFile().appendText(s + "\n") } catch (ignored: Throwable) {} }
    fun changeMirror(b: Boolean) { mirror = b; prefs().edit().putBoolean("mirror", b).apply(); ui() }
    private var handlerSet = false
    val hasPin: Boolean get() = pin != null

    private var pin: String? = null
    private lateinit var ctx: Context
    private val io = Executors.newSingleThreadExecutor()
    private val http = OkHttpClient.Builder().pingInterval(25, TimeUnit.SECONDS).build()
    private var ws: WebSocket? = null
    private var lan: WebSocketServer? = null
    private var lanConn: LanSocket? = null
    private var via = "cloud"
    private var lanFails = 0
    private var lanLock = 0L
    private var adb: Dadb? = null
    private var factory: PeerConnectionFactory? = null
    private var egl: EglBase? = null
    private var track: VideoTrack? = null
    private var pc: PeerConnection? = null
    private var dc: DataChannel? = null
    private var fileDc: DataChannel? = null
    private var filePath = ""
    private var fileUri: String? = null
    private var fileReal: String? = null
    private var qH = 720; private var qFps = 30; private var qKbps = 3000; private var qCodec = "auto"
    private var cap: ScreenCapturerAndroid? = null
    private var videoSender: RtpSender? = null
    private var fileOut: java.io.OutputStream? = null
    private var fileName = ""; private var fileSize = 0L; private var fileGot = 0L

    private fun prefs() = ctx.getSharedPreferences("agent", Context.MODE_PRIVATE)
    fun ui() { lanIp = localIp(); onUi() }

    fun load(c: Context) {
        ctx = c.applicationContext
        server = prefs().getString("server", "") ?: ""
        pin = prefs().getString("pin", null)
        if (server.isNotEmpty() && cloud == "none") cloud = "offline"
        mirror = prefs().getBoolean("mirror", true)
        capLevel = prefs().getInt("cap", 0)
        val tf = traceFile()
        if (tf.exists()) {
            val lines = tf.readText().trim().lines().filter { it.isNotBlank() }
            tf.delete()
            if (lines.isNotEmpty() && lines.last() != "done") {
                lastTrace = lines.takeLast(8).joinToString("\n")
            }
        }
        val f = File(ctx.filesDir, "crash.txt")
        if (f.exists()) lastCrash = f.readText().take(900)
        if (!handlerSet) {
            handlerSet = true
            val old = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { t, e ->
                try { File(ctx.filesDir, "crash.txt").writeText(android.util.Log.getStackTraceString(e)) } catch (ignored: Throwable) {}
                old?.uncaughtException(t, e)
            }
        }
    }

    fun clearCrash() { lastCrash = ""; lastTrace = ""; try { File(ctx.filesDir, "crash.txt").delete() } catch (ignored: Throwable) {}; ui() }

    private fun fail(t: Throwable) {
        note = "${t.javaClass.simpleName}: ${t.message}".take(300)
        try { lanConn?.send(err("TV error: $note")) } catch (ignored: Throwable) {}
        ui()
    }
    private fun safe(block: () -> Unit) = io.execute { try { block() } catch (t: Throwable) { fail(t) } }

    fun normalize(input: String): String {
        val t = input.trim().removeSuffix("/")
        return when {
            t.isEmpty() -> ""
            t.startsWith("wss://") || t.startsWith("ws://") -> t
            t.startsWith("https://") -> "wss://" + t.removePrefix("https://")
            t.startsWith("http://") -> "ws://" + t.removePrefix("http://")
            else -> "wss://$t"
        }
    }

    fun setPin(p: String) { pin = p; prefs().edit().putString("pin", p).apply(); pushPin(); ui() }
    private fun pushPin() { pin?.let { ws?.send(JSONObject().put("type", "set-pin").put("pin", it).toString()) } }

    fun saveServer(s: String) {
        server = s; prefs().edit().putString("server", s).apply()
        cloud = if (s.isEmpty()) "none" else "offline"
        if (started) { if (ws != null) ws?.close(1000, "changed") else connectWs() }
        ui()
    }

    /** Stop everything: servers, connections, screen capture and ADB. */
    fun stop() {
        if (!started) return
        started = false
        try { ws?.close(1000, "stopped") } catch (ignored: Throwable) {}
        ws = null
        try { lan?.stop(300) } catch (ignored: Throwable) {}
        lan = null; lanConn = null
        try { pc?.close() } catch (ignored: Throwable) {}
        pc = null; dc = null; fileDc = null; closeFile()
        try { cap?.stopCapture(); cap?.dispose() } catch (ignored: Throwable) {}
        cap = null; track = null; videoSender = null; projection = null
        try { adb?.close() } catch (ignored: Throwable) {}
        adb = null; adbOk = false
        cloud = if (server.isEmpty()) "none" else "offline"
        ui()
    }

    /** Runs a shell command on this TV through ADB. */
    fun runShell(cmd: String): Boolean = try { adb?.shell(cmd); adb != null } catch (ignored: Throwable) { false }

    /** Silent self-update through ADB (no confirmation window). */
    fun installViaAdb(path: String): Boolean = try {
        val r = adb?.shell("pm install -r \"$path\"")
        r?.output?.contains("Success") == true
    } catch (ignored: Throwable) { false }

    fun start(c: Context) {
        if (started) return
        started = true; load(c)
        if (factory == null) initRtc()
        connectAdb(); startLan(); connectWs()
    }

    // ---------- ADB (loopback; one-time "Allow debugging" prompt on the TV) ----------
    private fun connectAdb() = Thread {
        while (started && adb == null) {
            try {
                val priv = File(ctx.filesDir, "adbkey"); val pub = File(ctx.filesDir, "adbkey.pub")
                if (!priv.exists()) AdbKeyPair.generate(priv, pub)
                val d = Dadb.create("127.0.0.1", 5555, AdbKeyPair.read(priv, pub))
                d.shell("echo ok"); if (started) { adb = d; adbOk = true; ui() } else { try { d.close() } catch (ignored: Throwable) {} }
            } catch (e: Exception) { adbOk = false; ui(); Thread.sleep(3000) }
        }
    }.start()

    private fun sh(cmd: String) = io.execute { try { adb?.shell(cmd) } catch (ignored: Exception) { adb = null; adbOk = false; ui(); connectAdb() } }

    private val keys = mapOf("DPAD_UP" to 19, "DPAD_DOWN" to 20, "DPAD_LEFT" to 21, "DPAD_RIGHT" to 22,
        "DPAD_CENTER" to 23, "BACK" to 4, "HOME" to 3, "VOLUME_UP" to 24, "VOLUME_DOWN" to 25,
        "MUTE" to 164, "MEDIA_PLAY_PAUSE" to 85, "POWER" to 26, "RECENTS" to 187, "MENU" to 82,
        "STOP" to 86, "MEDIA_NEXT" to 87, "MEDIA_PREV" to 88, "DEL" to 67, "ENTER" to 66)

    private fun handle(d: JSONObject) {
        val dm = ctx.resources.displayMetrics
        val svc = RemoteService.instance
        when (d.getString("t")) {
            "key" -> key(d.getString("k"), svc)
            "launch" -> launchApp(d.getString("pkg"))
            "text" -> typeText(d.getString("s"), svc)
            "quality" -> applyQuality(d)
            "apps" -> io.execute { try { sendApps() } catch (t: Throwable) { fail(t) } }
            "open" -> openSettings(d.getString("what"))
            "tap" -> {
                val x = d.getDouble("x") * dm.widthPixels; val y = d.getDouble("y") * dm.heightPixels
                if (adbOk) sh("input tap ${x.toInt()} ${y.toInt()}") else svc?.tap(x.toFloat(), y.toFloat())
            }
            "swipe" -> {
                val x1 = d.getDouble("x1") * dm.widthPixels; val y1 = d.getDouble("y1") * dm.heightPixels
                val x2 = d.getDouble("x2") * dm.widthPixels; val y2 = d.getDouble("y2") * dm.heightPixels
                if (adbOk) sh("input swipe ${x1.toInt()} ${y1.toInt()} ${x2.toInt()} ${y2.toInt()} 250") else svc?.swipe(x1.toFloat(), y1.toFloat(), x2.toFloat(), y2.toFloat(), 250)
            }
        }
        if (!adbOk && svc == null) sendStatus()
    }

    private fun key(k: String, svc: RemoteService?) {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (k == "DEL" && svc != null && svc.del()) return
        if (k == "ENTER" && svc != null) { svc.enter(); return }
        when (k) {
            "MEDIA_NEXT" -> media(am, KeyEvent.KEYCODE_MEDIA_NEXT)
            "MEDIA_PREV" -> media(am, KeyEvent.KEYCODE_MEDIA_PREVIOUS)
            "STOP" -> media(am, KeyEvent.KEYCODE_MEDIA_STOP)
            "VOLUME_UP" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            "VOLUME_DOWN" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, AudioManager.FLAG_SHOW_UI)
            "MUTE" -> am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, AudioManager.FLAG_SHOW_UI)
            "MEDIA_PLAY_PAUSE" -> {
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
                am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE))
            }
            else -> {
                if (adbOk) { keys[k]?.let { sh("input keyevent $it") } }
                else if (svc != null) {
                    when (k) {
                        "BACK" -> svc.back()
                        "HOME" -> svc.home()
                        "POWER" -> svc.power()
                        "RECENTS" -> svc.recents()
                        "DPAD_UP" -> svc.move(View.FOCUS_UP)
                        "DPAD_DOWN" -> svc.move(View.FOCUS_DOWN)
                        "DPAD_LEFT" -> svc.move(View.FOCUS_LEFT)
                        "DPAD_RIGHT" -> svc.move(View.FOCUS_RIGHT)
                        "DPAD_CENTER" -> svc.ok()
                    }
                }
            }
        }
    }

    /** Sends the list of apps that can be opened (name + package) to the phone, in small pieces. */
    private fun sendApps() {
        val pm = ctx.packageManager
        val seen = HashSet<String>()
        val items = mutableListOf<Pair<String, String>>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            for (ri in pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(cat), 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ctx.packageName || !seen.add(pkg)) continue
                items.add(Pair(ri.loadLabel(pm).toString(), pkg))
            }
        }
        items.sortBy { it.first.lowercase() }
        val chunks = items.chunked(30)
        if (chunks.isEmpty()) sendCtl(JSONObject().put("t", "apps").put("list", JSONArray()).put("last", true))
        for ((k, c) in chunks.withIndex()) {
            val arr = JSONArray()
            for (p in c) arr.put(JSONObject().put("n", p.first).put("p", p.second))
            sendCtl(JSONObject().put("t", "apps").put("list", arr).put("last", k == chunks.size - 1))
        }
    }

    private fun launchApp(pkg: String) {
        val found = ctx.packageManager.getLeanbackLaunchIntentForPackage(pkg) ?: ctx.packageManager.getLaunchIntentForPackage(pkg)
        val comp = found?.component
        if (adbOk && comp != null) { sh("am start -n " + comp.flattenToShortString()); return }
        if (adbOk) { sh("monkey -p $pkg -c android.intent.category.LEANBACK_LAUNCHER 1"); return }
        try {
            val i = ctx.packageManager.getLeanbackLaunchIntentForPackage(pkg) ?: ctx.packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); ctx.startActivity(i) } else { note = "App not installed: $pkg"; ui() }
        } catch (t: Throwable) { note = "Cannot launch $pkg: ${t.message}".take(200); ui() }
    }

    private fun media(am: AudioManager, code: Int) {
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun typeText(s: String, svc: RemoteService?) {
        if (svc != null && svc.typeText(s)) return
        if (adbOk) sh("input text '" + s.replace("'", "'\\''").replace(" ", "%s") + "'")
    }

    private fun openSettings(what: String) {
        val action = when (what) {
            "wifi" -> android.provider.Settings.ACTION_WIFI_SETTINGS
            "bluetooth" -> android.provider.Settings.ACTION_BLUETOOTH_SETTINGS
            else -> android.provider.Settings.ACTION_SETTINGS
        }
        if (adbOk) { sh("am start -a $action"); return }
        try { ctx.startActivity(Intent(action).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        catch (t: Throwable) { note = "Cannot open settings: ${t.message}".take(200); ui() }
    }

    private fun sendCtl(o: JSONObject) {
        try { dc?.send(DataChannel.Buffer(java.nio.ByteBuffer.wrap(o.toString().toByteArray()), false)) } catch (ignored: Throwable) {}
    }

    // ---- file transfer: phone -> TV over the "file" data channel ----
    private fun closeFile() { try { fileOut?.close() } catch (ignored: Throwable) {}; fileOut = null }
    private fun onFileMsg(b: DataChannel.Buffer) {
        val bytes = ByteArray(b.data.remaining()).also { b.data.get(it) }
        if (!b.binary) {
            val h = JSONObject(String(bytes))
            if (h.optString("t") != "file") return
            closeFile()
            fileName = h.getString("name").replace(Regex("[^A-Za-z0-9._ -]"), "_")
            fileSize = h.getLong("size"); fileGot = 0
            val (os, shown) = openOut(fileName)
            fileOut = os; filePath = shown
            note = "Receiving $fileName ..."; ui()
            if (fileSize == 0L) finishFile()
        } else {
            fileOut?.write(bytes); fileGot += bytes.size
            if (fileGot >= fileSize) finishFile()
        }
    }
    private fun finishFile() {
        closeFile(); note = "Saved: $filePath"; ui()
        try { Received.add(ctx, fileName, filePath, fileUri, fileReal, fileGot) } catch (ignored: Throwable) {}
        sendCtl(JSONObject().put("t", "fileok").put("name", fileName).put("path", filePath))
    }

    /** Save into the public Downloads folder (visible in any file manager). */
    private fun openOut(name: String): Pair<java.io.OutputStream, String> {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                val v = android.content.ContentValues().apply {
                    put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS + "/ATC TV")
                }
                val uri = ctx.contentResolver.insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                val os = if (uri != null) ctx.contentResolver.openOutputStream(uri) else null
                if (os != null) { fileUri = uri?.toString(); fileReal = null; return Pair(os, "Download/ATC TV/$name") }
            } else if (ctx.checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                val dir = File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS), "ATC TV")
                dir.mkdirs()
                fileUri = null; fileReal = File(dir, name).path
                return Pair(java.io.FileOutputStream(File(dir, name)), "Download/ATC TV/$name")
            }
        } catch (t: Throwable) { note = "Public Downloads failed: ${t.message}".take(120) }
        val dir = ctx.getExternalFilesDir(android.os.Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir
        dir.mkdirs()
        fileUri = null; fileReal = File(dir, name).path
        return Pair(java.io.FileOutputStream(File(dir, name)), "${dir.path}/$name (allow Storage permission to save in Downloads)")
    }

    // ---- video quality / format chosen on the phone ----
    private fun capSize(): Pair<Int, Int> {
        val dm = ctx.resources.displayMetrics
        val a = maxOf(dm.widthPixels, dm.heightPixels).toFloat() / minOf(dm.widthPixels, dm.heightPixels)
        val short = qH and 1.inv()
        val long = (qH * a).toInt() and 1.inv()
        return if (dm.widthPixels >= dm.heightPixels) Pair(long, short) else Pair(short, long)
    }
    private fun applyCaptureFormat() {
        try { val (w, h) = capSize(); cap?.changeCaptureFormat(w, h, qFps) } catch (t: Throwable) { note = "Resolution: ${t.message}".take(120); ui() }
    }
    private fun applyBitrate() {
        try {
            val s = videoSender ?: return
            val p = s.getParameters()
            if (p.encodings.isNotEmpty()) {
                p.encodings[0].maxBitrateBps = qKbps * 1000
                p.encodings[0].maxFramerate = qFps
                s.setParameters(p)
            }
        } catch (t: Throwable) { note = "Bitrate: ${t.message}".take(120); ui() }
    }
    // ---- TV-side limit: the phone can ask for anything, the TV never sends more than this ----
    private var capLevel = 0
    private var reqH = 720; private var reqFps = 30; private var reqKbps = 3000
    val capName: String get() = when (capLevel) { 1 -> "480p max"; 2 -> "720p max"; 3 -> "1080p max"; else -> "none" }
    private fun recompute() {
        val (mh, mf, mk) = when (capLevel) {
            1 -> Triple(480, 24, 1500)
            2 -> Triple(720, 30, 3500)
            3 -> Triple(1080, 30, 6000)
            else -> Triple(1440, 60, 20000)
        }
        qH = minOf(reqH, mh); qFps = minOf(reqFps, mf); qKbps = minOf(reqKbps, mk)
    }
    fun cycleCap() {
        capLevel = (capLevel + 1) % 4
        prefs().edit().putInt("cap", capLevel).apply()
        recompute(); applyCaptureFormat(); applyBitrate(); ui()
    }
    private fun applyQuality(o: JSONObject) {
        reqH = o.optInt("h", reqH).coerceIn(240, 1440)
        reqFps = o.optInt("fps", reqFps).coerceIn(5, 60)
        reqKbps = o.optInt("kbps", reqKbps).coerceIn(200, 20000)
        qCodec = o.optString("codec", qCodec)
        recompute(); applyCaptureFormat(); applyBitrate()
    }
    /** Put the chosen codec first in the offer (H264 / VP8 / VP9). */
    private fun preferCodec(sdp: String, codec: String): String {
        val want = when (codec) { "h264" -> "H264"; "vp8" -> "VP8"; "vp9" -> "VP9"; else -> return sdp }
        val lines = sdp.split("\r\n")
        val pts = lines.filter { it.startsWith("a=rtpmap:") && it.substringAfter(" ").substringBefore("/").equals(want, true) }
            .map { it.substringAfter("a=rtpmap:").substringBefore(" ") }
        if (pts.isEmpty()) return sdp
        return lines.joinToString("\r\n") { l ->
            if (l.startsWith("m=video")) {
                val parts = l.split(" ")
                val fmts = parts.drop(3)
                (parts.take(3) + pts.filter { it in fmts } + fmts.filter { it !in pts }).joinToString(" ")
            } else l
        }
    }

    /** Tell the phone whether this device can be controlled. */
    fun sendStatus() {
        try {
            val m = JSONObject().put("t", "status").put("adb", adbOk).put("a11y", RemoteService.instance != null).toString()
            dc?.send(DataChannel.Buffer(java.nio.ByteBuffer.wrap(m.toByteArray()), false))
        } catch (ignored: Throwable) {}
    }

    // ---------- Home Wi-Fi mode: the TV is its own server ----------
    private fun localIp(): String = try {
        NetworkInterface.getNetworkInterfaces().toList().flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it is Inet4Address && it.isSiteLocalAddress }?.hostAddress ?: ""
    } catch (e: Exception) { "" }

    private fun err(msg: String) = JSONObject().put("type", "error").put("msg", msg).toString()

    private fun startLan() {
        try {
            lan = object : WebSocketServer(InetSocketAddress(LAN_PORT)) {
                override fun onOpen(c: LanSocket, h: ClientHandshake) {}
                override fun onClose(c: LanSocket, code: Int, reason: String?, remote: Boolean) { if (c === lanConn) lanConn = null }
                override fun onMessage(c: LanSocket, message: String) { try { lanMessage(c, JSONObject(message)) } catch (ignored: Exception) {} }
                override fun onError(c: LanSocket?, e: Exception?) {}
                override fun onStart() {}
            }.also { it.isReuseAddr = true; it.start() }
        } catch (e: Exception) { }
        ui()
    }

    private fun lanMessage(c: LanSocket, m: JSONObject) {
        when (m.optString("type")) {
            "connect" -> {
                if (System.currentTimeMillis() < lanLock) { c.send(err("Locked, try again in a few minutes")); return }
                val saved = pin
                if (saved == null || !MessageDigest.isEqual(saved.toByteArray(), m.optString("pin").toByteArray())) {
                    if (++lanFails >= 5) { lanFails = 0; lanLock = System.currentTimeMillis() + 10 * 60000 }
                    c.send(err("Wrong code")); return
                }
                lanFails = 0; lanConn = c; via = "lan"; note = ""; resetTrace(); trace("lan connect ok"); m.optJSONObject("quality")?.let { applyQuality(it) }
                c.send(JSONObject().put("type", "connected").put("ice", JSONArray()).toString())
                safe { startPeer(JSONArray()) }
            }
            "sig" -> if (c === lanConn) safe { onSig(m.getJSONObject("data")) }
        }
    }

    // ---------- Internet mode (optional server) ----------
    private fun connectWs() {
        if (server.isEmpty()) { cloud = "none"; ui(); return }
        val p = prefs()
        val req = try { Request.Builder().url(server).build() } catch (e: Exception) { cloud = "offline"; ui(); return }
        ws = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(w: WebSocket, r: Response) {
                w.send(JSONObject().put("type", "tv-hello").put("id", p.getString("id", null)).put("key", p.getString("key", null)).toString())
            }
            override fun onMessage(w: WebSocket, t: String) {
                val m = JSONObject(t)
                when (m.getString("type")) {
                    "tv-ok" -> {
                        id = m.getString("id"); p.edit().putString("id", id).putString("key", m.getString("key")).apply()
                        cloud = "online"; if (!m.getBoolean("hasPin")) pushPin(); ui()
                    }
                    "peer" -> { via = "cloud"; resetTrace(); m.optJSONObject("quality")?.let { applyQuality(it) }; safe { startPeer(m.getJSONArray("ice")) } }
                    "sig" -> if (via == "cloud") safe { onSig(m.getJSONObject("data")) }
                }
            }
            override fun onFailure(w: WebSocket, e: Throwable, r: Response?) { retry() }
            override fun onClosed(w: WebSocket, c: Int, r: String) { retry() }
            fun retry() { if (!started) return; cloud = if (server.isEmpty()) "none" else "offline"; ui(); Thread.sleep(3000); if (started) connectWs() }
        })
    }

    private fun sig(o: JSONObject) {
        val msg = JSONObject().put("type", "sig").put("data", o).toString()
        if (via == "lan") lanConn?.send(msg) else ws?.send(msg)
    }

    // ---------- WebRTC (same for both modes) ----------
    private fun initRtc() {
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(ctx).createInitializationOptions())
        egl = EglBase.create()
        factory = PeerConnectionFactory.builder()
            .setVideoEncoderFactory(DefaultVideoEncoderFactory(egl!!.eglBaseContext, true, true))
            .setVideoDecoderFactory(DefaultVideoDecoderFactory(egl!!.eglBaseContext)).createPeerConnectionFactory()
    }

    private fun ensureTrack() {
        if (!mirror) { note = "Screen mirroring is OFF (controls only)"; return }
        val proj = projection ?: run { note = "No screen-capture permission: controls only"; return }
        if (track != null) return
        try {
            val c = ScreenCapturerAndroid(proj, object : MediaProjection.Callback() {})
            val src = factory!!.createVideoSource(true)
            c.initialize(SurfaceTextureHelper.create("cap", egl!!.eglBaseContext), ctx, src.capturerObserver)
            val (cw, chh) = capSize()
            c.startCapture(cw, chh, qFps)
            cap = c
            track = factory!!.createVideoTrack("screen", src)
        } catch (t: Throwable) {
            track = null; note = "Screen capture failed (controls only): ${t.javaClass.simpleName}: ${t.message}".take(250)
        }
    }

    private fun startPeer(ice: JSONArray) {
        trace("peer begin (mirror ${if (mirror) "on" else "off"})")
        pc?.close()
        val servers = (0 until ice.length()).map {
            val o = ice.getJSONObject(it)
            val urls = mutableListOf<String>()
            val u = o.opt("urls")
            if (u is JSONArray) { for (k in 0 until u.length()) urls.add(u.getString(k)) } else if (u != null) urls.add(u.toString())
            val b = PeerConnection.IceServer.builder(urls)
            if (o.has("username")) b.setUsername(o.getString("username")).setPassword(o.getString("credential"))
            b.createIceServer()
        }
        val cfg = PeerConnection.RTCConfiguration(servers).apply { sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN }
        pc = factory!!.createPeerConnection(cfg, object : Obs() {
            override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {
                trace("ice $s")
                if (s == PeerConnection.IceConnectionState.CONNECTED || s == PeerConnection.IceConnectionState.COMPLETED) { trace("done"); applyBitrate() }
            }
            override fun onIceCandidate(c: IceCandidate) =
                sig(JSONObject().put("ice", JSONObject().put("candidate", c.sdp).put("sdpMid", c.sdpMid).put("sdpMLineIndex", c.sdpMLineIndex)))
        })!!
        trace("pc created"); trace("capture begin"); ensureTrack(); trace("capture end")
        track?.let { videoSender = pc!!.addTrack(it, listOf("s")); trace("track added") }
        dc = pc!!.createDataChannel("ctl", DataChannel.Init()); trace("datachannel created")
        dc!!.registerObserver(object : DataChannel.Observer {
            override fun onMessage(b: DataChannel.Buffer) {
                val bytes = ByteArray(b.data.remaining()).also { b.data.get(it) }
                try { handle(JSONObject(String(bytes))) } catch (t: Throwable) { fail(t) }
            }
            override fun onBufferedAmountChange(l: Long) {}
            override fun onStateChange() { if (dc?.state() == DataChannel.State.OPEN) sendStatus() }
        })
        fileDc = pc!!.createDataChannel("file", DataChannel.Init())
        fileDc!!.registerObserver(object : DataChannel.Observer {
            override fun onMessage(b: DataChannel.Buffer) { try { onFileMsg(b) } catch (t: Throwable) { fail(t) } }
            override fun onBufferedAmountChange(l: Long) {}
            override fun onStateChange() {}
        })
        pc!!.createOffer(object : Sdp() {
            override fun onCreateSuccess(d: SessionDescription) {
                trace("offer ready")
                val d2 = SessionDescription(d.type, preferCodec(d.description, qCodec))
                pc!!.setLocalDescription(object : Sdp() { override fun onSetSuccess() { trace("local desc set") } }, d2)
                sig(JSONObject().put("sdp", d2.description).put("sdpType", "offer"))
                trace("offer sent")
            }
        }, MediaConstraints())
    }

    private fun onSig(d: JSONObject) {
        if (d.has("sdp")) { trace("answer received"); pc?.setRemoteDescription(object : Sdp() { override fun onSetSuccess() { trace("answer set") } }, SessionDescription(SessionDescription.Type.ANSWER, d.getString("sdp"))) }
        else if (d.has("ice")) d.getJSONObject("ice").let { pc?.addIceCandidate(IceCandidate(it.getString("sdpMid"), it.getInt("sdpMLineIndex"), it.getString("candidate"))) }
    }

    open class Sdp : SdpObserver {
        override fun onCreateSuccess(d: SessionDescription) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(e: String?) {}
        override fun onSetFailure(e: String?) {}
    }
    open class Obs : PeerConnection.Observer {
        override fun onSignalingChange(s: PeerConnection.SignalingState?) {}
        override fun onIceConnectionChange(s: PeerConnection.IceConnectionState?) {}
        override fun onIceConnectionReceivingChange(b: Boolean) {}
        override fun onIceGatheringChange(s: PeerConnection.IceGatheringState?) {}
        override fun onIceCandidate(c: IceCandidate) {}
        override fun onIceCandidatesRemoved(c: Array<out IceCandidate>?) {}
        override fun onAddStream(s: MediaStream?) {}
        override fun onRemoveStream(s: MediaStream?) {}
        override fun onDataChannel(d: DataChannel?) {}
        override fun onRenegotiationNeeded() {}
        override fun onAddTrack(r: RtpReceiver?, s: Array<out MediaStream>?) {}
    }
}
