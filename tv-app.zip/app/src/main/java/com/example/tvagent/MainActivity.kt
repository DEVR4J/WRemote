package com.example.tvagent

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var server: EditText
    private lateinit var saveServer: Button
    private lateinit var changeServer: Button
    private lateinit var pin: EditText
    private lateinit var savePin: Button
    private lateinit var changePin: Button
    private lateinit var clearCrash: Button
    private lateinit var mirrorBtn: Button
    private var serverForm = false
    private var editPin = false

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Agent.load(this)
        status = TextView(this).apply { textSize = 26f; gravity = Gravity.CENTER }
        pin = EditText(this).apply { hint = "Choose a 6-digit code"; inputType = 2; textSize = 26f }
        savePin = Button(this).apply {
            text = "Save code"
            setOnClickListener {
                if (pin.text.length == 6) { Agent.setPin(pin.text.toString()); editPin = false; pin.setText(""); render() }
                else pin.error = "Needs 6 digits"
            }
        }
        changePin = Button(this).apply { text = "Change code"; setOnClickListener { editPin = true; render() } }
        mirrorBtn = Button(this).apply { setOnClickListener { Agent.changeMirror(!Agent.mirror) } }
        clearCrash = Button(this).apply { text = "Dismiss crash log"; setOnClickListener { Agent.clearCrash() } }
        server = EditText(this).apply { hint = "Internet server, e.g. myserver.onrender.com (leave empty to turn off)"; textSize = 22f; setSingleLine() }
        saveServer = Button(this).apply {
            text = "Save server"
            setOnClickListener { Agent.saveServer(Agent.normalize(server.text.toString())); serverForm = false; render() }
        }
        changeServer = Button(this).apply {
            setOnClickListener { server.setText(Agent.server.removePrefix("wss://")); serverForm = true; render() }
        }
        setContentView(ScrollView(this).apply { addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL; setPadding(120, 60, 120, 60)
            addView(status); addView(mirrorBtn); addView(clearCrash); addView(pin); addView(savePin); addView(changePin)
            addView(server); addView(saveServer); addView(changeServer)
        }) })
        Agent.onUi = { runOnUiThread { render() } }
        begin(); render()
    }

    private fun begin() {
        if (Agent.started) return
        try { // one-time permission: screen capture
            startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
        } catch (e: Exception) { launchService(null) } // TV without the dialog: control-only mode
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) { if (r == 1) launchService(if (c == RESULT_OK) d else null) }
    private fun launchService(p: Intent?) { Agent.projection = p; startForegroundService(Intent(this, AgentService::class.java)) }

    private fun render() {
        val l = mutableListOf<String>()
        l += if (Agent.lanIp.isNotEmpty()) "HOME Wi-Fi\nEnter ${Agent.lanIp} in the phone app" else "HOME Wi-Fi: TV not on a network"
        l += when (Agent.cloud) {
            "online" -> "INTERNET\nTV ID ${Agent.id?.chunked(3)?.joinToString(" ") ?: "…"}"
            "offline" -> "INTERNET\nCannot reach ${Agent.server.removePrefix("wss://")}"
            else -> "INTERNET: not set up (optional)"
        }
        l += if (Agent.hasPin) "Code: set" else "Set your 6-digit code below"
        l += if (Agent.adbOk) "Control: OK" else "Control: waiting for ADB.\nSettings > Developer options > turn on USB debugging (and Network debugging if shown), then press Allow."
        if (Agent.note.isNotEmpty()) l += "Note: ${Agent.note}"
        if (Agent.lastCrash.isNotEmpty()) l += "LAST CRASH:\n" + Agent.lastCrash.take(500)
        if (Agent.lastTrace.isNotEmpty()) l += "LAST CONNECT (app died after these steps):\n${Agent.lastTrace}"
        mirrorBtn.text = if (Agent.mirror) "Screen mirroring: ON (tap to turn off)" else "Screen mirroring: OFF (tap to turn on)"
        clearCrash.visibility = if (Agent.lastCrash.isNotEmpty() || Agent.lastTrace.isNotEmpty()) View.VISIBLE else View.GONE
        status.text = l.joinToString("\n\n")
        val showPin = !Agent.hasPin || editPin
        pin.visibility = if (showPin) View.VISIBLE else View.GONE
        savePin.visibility = pin.visibility
        changePin.visibility = if (showPin) View.GONE else View.VISIBLE
        server.visibility = if (serverForm) View.VISIBLE else View.GONE
        saveServer.visibility = server.visibility
        changeServer.text = if (Agent.server.isEmpty()) "Set up internet access" else "Change server"
        changeServer.visibility = if (serverForm) View.GONE else View.VISIBLE
    }
}
