package com.example.tvagent

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var pin: EditText
    private lateinit var save: Button

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        status = TextView(this).apply { textSize = 30f; gravity = Gravity.CENTER }
        pin = EditText(this).apply { hint = "Choose a 6-digit code"; inputType = 2; textSize = 28f; visibility = View.GONE }
        save = Button(this).apply {
            text = "Save code"; visibility = View.GONE
            setOnClickListener { if (pin.text.length == 6) Agent.setPin(pin.text.toString()) else pin.error = "Needs 6 digits" }
        }
        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(120, 80, 120, 80)
            addView(status); addView(pin); addView(save)
        })
        Agent.onUi = { st, id, adb -> runOnUiThread { render(st, id, adb) } }
        if (Agent.started) { Agent.ui(); return }
        try { // one-time permission: screen capture
            startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
        } catch (e: Exception) { launchService(null) } // TV without the dialog: control-only mode
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) { launchService(if (c == RESULT_OK) d else null) }
    private fun launchService(p: Intent?) { Agent.projection = p; startForegroundService(Intent(this, AgentService::class.java)) }

    private fun render(cloud: String, id: String?, adb: Boolean) {
        val idTxt = id?.chunked(3)?.joinToString(" ") ?: "…"
        val lines = mutableListOf<String>()
        lines += if (cloud == "offline") "Connecting to server…" else "Your TV ID\n$idTxt"
        if (cloud == "needpin") lines += "Set a 6-digit code below"
        if (cloud == "ready") lines += "Ready. Open the phone app."
        lines += if (adb) "Control: OK" else "Control: waiting for ADB.\nSettings > Developer options > turn on USB debugging (and Network debugging if shown), then press Allow."
        status.text = lines.joinToString("\n\n")
        val need = cloud == "needpin"
        pin.visibility = if (need) View.VISIBLE else View.GONE
        save.visibility = pin.visibility
    }
}
