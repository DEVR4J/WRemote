package com.example.tvagent

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var runBtn: Button
    private lateinit var server: EditText
    private lateinit var saveServer: Button
    private lateinit var changeServer: Button
    private lateinit var pin: EditText
    private lateinit var savePin: Button
    private lateinit var changePin: Button
    private lateinit var clearCrash: Button
    private lateinit var mirrorBtn: Button
    private lateinit var a11yBtn: Button
    private lateinit var updateBtn: Button
    private lateinit var autoUpdBtn: Button
    private var serverForm = false
    private var editPin = false

    private fun prefs() = getSharedPreferences("agent", MODE_PRIVATE)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Agent.load(this)
        status = TextView(this).apply { textSize = 24f; gravity = Gravity.CENTER }
        runBtn = Button(this).apply {
            setOnClickListener {
                if (Agent.started) {
                    prefs().edit().putBoolean("autostart", false).apply()
                    Agent.stop(); stopService(Intent(this@MainActivity, AgentService::class.java))
                } else {
                    prefs().edit().putBoolean("autostart", true).apply()
                    begin()
                }
                render()
            }
        }
        pin = EditText(this).apply { hint = "Choose a 6-digit code"; inputType = 2; textSize = 26f }
        savePin = Button(this).apply {
            text = "Save code"
            setOnClickListener {
                if (pin.text.length == 6) { Agent.setPin(pin.text.toString()); editPin = false; pin.setText(""); render() }
                else pin.error = "Needs 6 digits"
            }
        }
        changePin = Button(this).apply { text = "Change code"; setOnClickListener { editPin = true; render() } }
        a11yBtn = Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { try { startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) { Agent.note = "Open Settings > Accessibility by hand"; Agent.ui() } }
        }
        updateBtn = Button(this).apply {
            setOnClickListener {
                val i = Updater.info
                if (i != null && i.build > Updater.BUILD) Thread { Updater.installLatest(this@MainActivity) }.start()
                else Thread { Updater.check(this@MainActivity, false) }.start()
            }
        }
        autoUpdBtn = Button(this).apply {
            setOnClickListener { prefs().edit().putBoolean("autoupdate", !prefs().getBoolean("autoupdate", true)).apply(); render() }
        }
        mirrorBtn = Button(this).apply { setOnClickListener { Agent.changeMirror(!Agent.mirror) } }
        clearCrash = Button(this).apply { text = "Dismiss crash log"; setOnClickListener { Agent.clearCrash() } }
        server = EditText(this).apply { hint = "Internet server, e.g. myserver.workers.dev (leave empty to turn off)"; textSize = 22f; setSingleLine() }
        saveServer = Button(this).apply {
            text = "Save server"
            setOnClickListener { Agent.saveServer(Agent.normalize(server.text.toString())); serverForm = false; render() }
        }
        changeServer = Button(this).apply {
            setOnClickListener { server.setText(Agent.server.removePrefix("wss://").removePrefix("ws://")); serverForm = true; render() }
        }
        setContentView(ScrollView(this).apply { addView(LinearLayout(this@MainActivity).apply {
            orientation = LinearLayout.VERTICAL; setPadding(120, 60, 120, 60)
            addView(status); addView(runBtn); addView(updateBtn); addView(autoUpdBtn); addView(a11yBtn); addView(mirrorBtn); addView(clearCrash)
            addView(pin); addView(savePin); addView(changePin)
            addView(server); addView(saveServer); addView(changeServer)
        }) })
        Agent.onUi = { runOnUiThread { render() } }
        if (prefs().getBoolean("autostart", true)) begin()
        if (prefs().getBoolean("autoupdate", true)) Thread { Updater.check(this@MainActivity, true) }.start()
        render()
    }

    private fun begin() {
        if (Agent.started) return
        try { // one-time permission: screen capture
            startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
        } catch (e: Exception) { launchService(null) } // TV without the dialog: control-only mode
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) { if (r == 1) launchService(if (c == RESULT_OK) d else null) }
    private fun launchService(p: Intent?) { Agent.projection = p; startForegroundService(Intent(this, AgentService::class.java)); askStorage() }
    /** Android 9 and older need this to save received files into Downloads. */
    private fun askStorage() {
        if (android.os.Build.VERSION.SDK_INT in 23..28 &&
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 2)
    }

    private fun render() {
        val host = Agent.server.removePrefix("wss://").removePrefix("ws://")
        val l = mutableListOf<String>()
        l += if (Agent.started) "SERVICE: RUNNING" else "SERVICE: STOPPED"
        if (Agent.started) {
            l += if (Agent.lanIp.isNotEmpty()) "HOME Wi-Fi\nEnter ${Agent.lanIp} in the phone app" else "HOME Wi-Fi: TV not on a network"
            l += when (Agent.cloud) {
                "online" -> "INTERNET: connected to $host\nTV ID ${Agent.id?.chunked(3)?.joinToString(" ") ?: "..."}"
                "offline" -> "INTERNET: cannot reach $host"
                else -> "INTERNET: not set up (optional)"
            }
            l += if (Agent.hasPin) "Code: set" else "Set your 6-digit code below"
            l += when {
                Agent.adbOk -> "Control: OK (ADB)"
                RemoteService.instance != null -> "Control: OK (accessibility)"
                else -> "Control: OFF. Turn on Remote Agent in Accessibility settings (button below), or turn on USB debugging."
            }
        } else {
            l += if (Agent.server.isEmpty()) "Internet server: not set" else "Internet server: $host"
            l += if (Agent.hasPin) "Code: set" else "Set your 6-digit code below"
        }
        if (Agent.note.isNotEmpty()) l += "Note: ${Agent.note}"
        if (Agent.lastCrash.isNotEmpty()) l += "LAST CRASH:\n" + Agent.lastCrash.take(500)
        if (Agent.lastTrace.isNotEmpty()) l += "LAST CONNECT (app died after these steps):\n${Agent.lastTrace}"
        l += "VERSION: build ${Updater.BUILD}" + (if (Updater.status.isNotEmpty()) "\n${Updater.status}" else "")
        status.text = l.joinToString("\n\n")
        runBtn.text = if (Agent.started) "Stop service" else "Start service"
        val newer = Updater.info
        updateBtn.text = if (newer != null && newer.build > Updater.BUILD) "Install update ${newer.tag}" else "Check for updates"
        autoUpdBtn.text = if (prefs().getBoolean("autoupdate", true)) "Auto-update: ON (tap to turn off)" else "Auto-update: OFF (tap to turn on)"
        a11yBtn.visibility = if (RemoteService.instance == null) View.VISIBLE else View.GONE
        mirrorBtn.text = if (Agent.mirror) "Screen mirroring: ON (tap to turn off)" else "Screen mirroring: OFF (tap to turn on)"
        clearCrash.visibility = if (Agent.lastCrash.isNotEmpty() || Agent.lastTrace.isNotEmpty()) View.VISIBLE else View.GONE
        val showPin = !Agent.hasPin || editPin
        pin.visibility = if (showPin) View.VISIBLE else View.GONE
        savePin.visibility = pin.visibility
        changePin.visibility = if (showPin) View.GONE else View.VISIBLE
        server.visibility = if (serverForm) View.VISIBLE else View.GONE
        saveServer.visibility = server.visibility
        changeServer.text = if (Agent.server.isEmpty()) "Set up internet access" else "Change server"
        changeServer.visibility = if (serverForm) View.GONE else View.VISIBLE
    }
}
