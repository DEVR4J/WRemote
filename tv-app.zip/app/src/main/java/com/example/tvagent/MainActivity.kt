package com.example.tvagent

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var qrText: TextView
    private lateinit var btnStart: Button
    private lateinit var btnMirror: Button
    private lateinit var btnCode: Button
    private lateinit var btnServer: Button
    private lateinit var btnCrash: Button
    private lateinit var btnUpdate: Button
    private lateinit var btnAuto: Button
    private lateinit var btnLimit: Button
    private lateinit var btnA11y: Button
    private lateinit var btnFiles: Button
    private lateinit var btnQr: Button

    private fun prefs() = getSharedPreferences("agent", MODE_PRIVATE)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        setContentView(R.layout.activity_main)
        Agent.load(this)
        status = findViewById(R.id.statusText)
        qrText = findViewById(R.id.qrText)
        btnStart = findViewById(R.id.btnStart); btnMirror = findViewById(R.id.btnMirror)
        btnCode = findViewById(R.id.btnCode); btnServer = findViewById(R.id.btnServer)
        btnCrash = findViewById(R.id.btnCrash); btnUpdate = findViewById(R.id.btnUpdate)
        btnAuto = findViewById(R.id.btnAuto); btnLimit = findViewById(R.id.btnLimit); btnA11y = findViewById(R.id.btnA11y)
        btnFiles = findViewById(R.id.btnFiles); btnQr = findViewById(R.id.btnQr)

        findViewById<TextView>(R.id.tagline).text = "Your parents' TV troubles are now your problem... remotely."
        findViewById<TextView>(R.id.taglineSmall).text = "Created by someone who got tired of hearing 'Beta, TV nahi chal raha!' " +
            "Anywhere TV lets you control your television remotely, so your not-so-tech-friendly loved ones never miss their favourite episodes, " +
            "and you never have to explain which button to press over a video call again."
        qrText.text = "Scan QR  >>\nTo Download and Install this apk on your Android device from which you want to control this TV\n\nYou'll get tutorial on how to use this app on ATC - Phone App."
        findViewById<TextView>(R.id.madeWith).text = "Made with \uD83D\uDC9C by DS Yadav"

        btnStart.setOnClickListener {
            if (Agent.started) {
                prefs().edit().putBoolean("autostart", false).apply()
                Agent.stop(); stopService(Intent(this, AgentService::class.java))
            } else {
                prefs().edit().putBoolean("autostart", true).apply()
                begin()
            }
            render()
        }
        btnMirror.setOnClickListener { Agent.changeMirror(!Agent.mirror) }
        btnCode.setOnClickListener { askCode() }
        btnServer.setOnClickListener { askServer() }
        btnCrash.setOnClickListener { Agent.clearCrash() }
        btnUpdate.setOnClickListener {
            val i = Updater.info
            if (i != null && i.build > Updater.BUILD) Thread { Updater.installLatest(this) }.start()
            else Thread { Updater.check(this, false) }.start()
        }
        btnAuto.setOnClickListener { prefs().edit().putBoolean("autoupdate", !prefs().getBoolean("autoupdate", true)).apply(); render() }
        btnLimit.setOnClickListener { Agent.cycleCap() }
        btnFiles.setOnClickListener { startActivity(Intent(this, FilesActivity::class.java)) }
        btnQr.setOnClickListener { startActivity(Intent(this, QrActivity::class.java)) }
        btnA11y.setOnClickListener {
            try { startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            catch (e: Exception) { Agent.note = "Open Settings > Accessibility by hand"; Agent.ui() }
        }

        Agent.onUi = { runOnUiThread { render() } }
        if (prefs().getBoolean("autostart", true)) begin()
        if (prefs().getBoolean("autoupdate", true)) Thread { Updater.check(this, true) }.start()
        render()
    }

    private fun begin() {
        if (Agent.started) return
        try { // one-time permission: screen capture
            startActivityForResult(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent(), 1)
        } catch (e: Exception) { launchService(null) } // TV without the dialog: control-only mode
    }

    override fun onActivityResult(r: Int, c: Int, d: Intent?) { if (r == 1) launchService(if (c == RESULT_OK) d else null) }
    private fun launchService(p: Intent?) { Agent.projection = p; startForegroundService(Intent(this, AgentService::class.java)); askStorage() }
    /** Android 9 and older need this to save received files into Downloads. */
    private fun askStorage() {
        if (android.os.Build.VERSION.SDK_INT in 23..28 &&
            checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(android.Manifest.permission.WRITE_EXTERNAL_STORAGE), 2)
    }

    // ---------------- dialogs ----------------
    private fun askCode() {
        val et = EditText(this).apply { inputType = InputType.TYPE_CLASS_NUMBER; filters = arrayOf(InputFilter.LengthFilter(6)); hint = "6 digits"; textSize = 24f }
        AlertDialog.Builder(this).setTitle("Choose a 6-digit code").setView(et)
            .setPositiveButton("Save") { _, _ ->
                if (et.text.length == 6) Agent.setPin(et.text.toString()) else Toast.makeText(this, "The code needs 6 digits", Toast.LENGTH_LONG).show()
            }.setNegativeButton("Cancel", null).show()
    }

    private fun askServer() {
        val et = EditText(this).apply { hint = "e.g. myserver.workers.dev"; setSingleLine(); textSize = 20f
            setText(Agent.server.removePrefix("wss://").removePrefix("ws://")) }
        AlertDialog.Builder(this).setTitle("Internet server address").setView(et)
            .setPositiveButton("Save") { _, _ -> Agent.saveServer(Agent.normalize(et.text.toString())) }
            .setNeutralButton("Remove") { _, _ -> Agent.saveServer("") }
            .setNegativeButton("Cancel", null).show()
    }

    // ---------------- status box and buttons ----------------
    private fun render() {
        val host = Agent.server.removePrefix("wss://").removePrefix("ws://")
        val l = mutableListOf<String>()
        l += "Service: " + if (Agent.started) "RUNNING" else "STOPPED"
        l += "Internet Server: " + when {
            Agent.server.isEmpty() -> "Not set"
            Agent.started && Agent.cloud == "online" -> "$host (connected)"
            Agent.started && Agent.cloud == "offline" -> "$host (cannot reach)"
            else -> host
        }
        l += "Code: " + if (Agent.hasPin) "Set" else "Not set"
        if (Agent.started) {
            l += "Home Wi-Fi address: " + (if (Agent.lanIp.isNotEmpty()) Agent.lanIp else "TV is not on a network")
            if (Agent.cloud == "online") l += "TV ID: " + (Agent.id?.chunked(3)?.joinToString(" ") ?: "...")
            l += "Control: " + when {
                Agent.adbOk -> "OK (ADB)"
                RemoteService.instance != null -> "OK (accessibility)"
                else -> "OFF. Turn on USB debugging, or Remote Agent in Accessibility settings"
            }
        }
        l += "Note: " + Agent.note
        if (Agent.lastCrash.isNotEmpty()) l += "LAST CRASH:\n" + Agent.lastCrash.take(500)
        if (Agent.lastTrace.isNotEmpty()) l += "LAST CONNECT (app died after these steps):\n" + Agent.lastTrace
        val vs = Updater.status
        val state = when {
            vs.startsWith("Up to date") -> "up to date"
            vs.isEmpty() -> "not checked"
            else -> vs.lowercase()
        }
        l += "Version: Build " + (if (Updater.BUILD == 0) "___" else Updater.BUILD.toString()) + " ( $state )"
        status.text = l.joinToString("\n")

        btnStart.text = if (Agent.started) "Stop service" else "Start service"
        btnMirror.text = if (Agent.mirror) "Screen mirroring: ON ( tap to turn off )" else "Screen mirroring: OFF ( tap to turn on )"
        btnCode.text = if (Agent.hasPin) "Change code" else "Set code"
        btnServer.text = if (Agent.server.isEmpty()) "Set server" else "Change server"
        btnCrash.text = "Dismiss crash log"
        val newer = Updater.info
        btnUpdate.text = if (newer != null && newer.build > Updater.BUILD) "Install update ${newer.tag}" else "Check for update"
        btnAuto.text = if (prefs().getBoolean("autoupdate", true)) "Auto update: ON ( tap to turn off )" else "Auto update: OFF ( tap to turn on )"
        btnLimit.text = "Video limit: ${Agent.capName} ( tap to change )"
        btnFiles.text = "Received files"
        btnQr.text = "See QR"
        btnA11y.text = "Open accessibility settings"
        btnA11y.visibility = if (RemoteService.instance == null) View.VISIBLE else View.GONE
    }
}
